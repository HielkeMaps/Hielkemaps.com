data modify entity @s LifeTime set value 20

spreadplayers -170 -146 0 20 under 10 true @s
tag @s add tped