tp @s -738 5 -44 270 0
clear @s *[minecraft:custom_data~{"hielkemaps:item":true},!minecraft:custom_data~{"tm:item":true}]
function time:reset
scoreboard players reset @s level
scoreboard players reset @s level_display