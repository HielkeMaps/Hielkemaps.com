attribute @s minecraft:burning_time base set 0.001

tp @s -772 5 -44 270 10
gamemode adventure @s
tag @s remove ingame
scoreboard players reset @s level
scoreboard players reset @s level_display

function time:reset

tag @s add joined

clear @s *[minecraft:custom_data~{"hielkemaps:item":true}]
execute as @s[tag=training_mode] run function trainingmode:leave