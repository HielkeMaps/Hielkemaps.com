# Timers
execute as @e[type=marker,name=console,limit=1] run function main:timer/tick