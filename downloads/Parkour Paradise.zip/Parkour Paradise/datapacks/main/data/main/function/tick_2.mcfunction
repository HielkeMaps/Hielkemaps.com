#runs every 2 ticks
schedule function main:tick_2 2t


#PLAYSOUNDS
execute as @a[tag=playsound_levelup] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 0.5 1
tag @a remove playsound_levelup

execute as @a[tag=playsound_warp] at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 1
tag @a remove playsound_warp

execute as @a[tag=playsound_portal] at @s run playsound minecraft:block.portal.travel master @s ~ ~ ~ 0.5 1 1
tag @a remove playsound_portal

#On join
execute as @a[tag=!joined] run function main:on_join

#Dont go out of spawn
execute positioned ~ 45 ~ as @a[distance=..15] if entity @s[x=-772,y=5,z=-44,distance=..100] run function main:tp/to_spawn

#Reset scores at spawn
scoreboard players reset @a[tag=!inRace,x=-772,y=5,z=-44,distance=..5] level
scoreboard players reset @a[tag=!inRace,x=-772,y=5,z=-44,distance=..5] time
scoreboard players reset @a[tag=!inRace,x=-772,y=5,z=-44,distance=..5] time_tick
tag @a[tag=!inRace,x=-772,y=5,z=-44,distance=..5] remove ingame

# Tp to start - start
execute as @a[x=-732,y=9,z=-44,distance=..15] at @s if block ~0.2999 ~ ~ minecraft:nether_portal run function main:tp/to_start
execute as @a[x=-732,y=9,z=-44,distance=..15] at @s if block ~ ~ ~ minecraft:nether_portal run function main:tp/to_start
execute as @a[x=-732,y=9,z=-44,distance=..15] at @s if block ~-0.2999 ~ ~ minecraft:nether_portal run function main:tp/to_start

#tp back to spawn
execute as @a[x=-178,y=9,z=-147,distance=..10] at @s if block ~ ~ ~ minecraft:end_gateway run function main:tp/to_spawn

execute as @a[scores={level=42},gamemode=!spectator] at @s if block ~ ~1 ~ minecraft:water run function main:tp/level42
execute as @a[x=-83,y=1,z=-51,distance=..3,gamemode=!spectator] at @s if block ~ ~-1.1 ~ minecraft:quartz_pillar run function main:tp/level59

#END
execute as @a[tag=ingame,x=-168,y=8,z=-147,distance=..15,gamemode=!spectator] at @s run function time:finish

#level
execute as @a[tag=ingame,gamemode=!spectator] run function main:setlevel

#reset trigger
scoreboard players enable @a reset
scoreboard players set @a[tag=inRace] reset 0
tag @a[scores={reset=1}] remove joined
scoreboard players set @a reset 0

#restart trigger
scoreboard players enable @a restart
scoreboard players set @a[tag=inRace] restart 0
execute as @a[scores={restart=1}] run function main:restart
scoreboard players set @a restart 0

execute if block -14 2 -32 minecraft:slime_block run setblock -14 0 -33 air