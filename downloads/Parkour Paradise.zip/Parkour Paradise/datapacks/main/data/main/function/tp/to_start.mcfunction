tp @s -98.0 104.00 5.5 270 89
tag @s[gamemode=!spectator] add start_timer

execute as @s[tag=!inRace,gamemode=!spectator] run function time:start