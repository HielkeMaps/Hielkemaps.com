#start timer
execute as @a[tag=start_timer] at @s run function main:timer/start