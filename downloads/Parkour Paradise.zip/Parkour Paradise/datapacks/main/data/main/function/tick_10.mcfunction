schedule function main:tick_10 10t

spawnpoint @a -772 5 -44
effect give @a saturation infinite 255 true
effect give @a resistance infinite 255 true

#kill items
execute as @e[type=item] unless items entity @s contents *[minecraft:custom_data~{"hielkemaps:stay":true}] run kill