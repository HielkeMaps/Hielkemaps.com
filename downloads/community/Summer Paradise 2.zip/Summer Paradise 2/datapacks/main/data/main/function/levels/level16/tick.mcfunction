#snake
execute if block 29 -12 157 #minecraft:wooden_pressure_plates[powered=true] run scoreboard players set @n[type=block_display,name=snake_1,tag=start,scores={snake_1=-1}] snake_1 0

execute as @e[type=block_display,name=snake_1,scores={snake_1=3}] at @s run scoreboard players set @e[type=block_display,name=snake_1,distance=0.1..1.1,scores={snake_1=-1}] snake_1 0

execute as @e[type=block_display,name=snake_1] unless score @s snake_1 matches -1 at @s run execute if score @s snake_1 matches 3 run setblock ~ ~ ~ light_gray_concrete
execute as @e[type=block_display,name=snake_1] unless score @s snake_1 matches -1 at @s run execute if score @s snake_1 matches 12 run setblock ~ ~ ~ gray_concrete
execute as @e[type=block_display,name=snake_1] unless score @s snake_1 matches -1 at @s run execute if score @s snake_1 matches 21 run setblock ~ ~ ~ light_gray_concrete
execute as @e[type=block_display,name=snake_1] unless score @s snake_1 matches -1 at @s run execute if score @s snake_1 matches 30 run setblock ~ ~ ~ gray_concrete
execute as @e[type=block_display,name=snake_1] unless score @s snake_1 matches -1 at @s run execute if score @s snake_1 matches 39 run setblock ~ ~ ~ light_gray_concrete
execute as @e[type=block_display,name=snake_1] unless score @s snake_1 matches -1 at @s run execute if score @s snake_1 matches 48 run setblock ~ ~ ~ gray_concrete
execute as @e[type=block_display,name=snake_1] unless score @s snake_1 matches -1 at @s run execute if score @s snake_1 matches 57 run setblock ~ ~ ~ air
execute as @e[type=block_display,name=snake_1] unless score @s snake_1 matches -1 at @s run scoreboard players add @s snake_1 1
execute as @e[type=block_display,name=snake_1] unless score @s snake_1 matches -1 at @s run scoreboard players set @s[scores={snake_1=58..}] snake_1 -60