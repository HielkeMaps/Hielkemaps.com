execute as @a[x=28.0,y=31.0,z=160.0,distance=..1,gamemode=!spectator] unless items entity @s armor.chest minecraft:elytra at @s run function main:util/elytra/pickup
execute as @a[tag=elytra] unless items entity @s armor.chest elytra run tag @s remove elytra
