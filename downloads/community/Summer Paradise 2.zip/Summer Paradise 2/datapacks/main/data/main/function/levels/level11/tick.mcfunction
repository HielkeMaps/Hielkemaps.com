execute unless entity @a[scores={level=11},tag=!afk] if block -6 -61 136 stripped_dark_oak_log run function main:levels/level11/shrink
scoreboard players add @n[type=marker,name=console,scores={logs=..0}] logs 1
execute positioned -4 -61 130 if entity @a[gamemode=!spectator,scores={level=11},distance=..3] unless score @n[type=marker,name=console] logs matches ..0 if block -6 -61 136 stripped_dark_oak_log run function main:levels/level11/shrink
execute positioned -4 -59 141 if entity @a[gamemode=!spectator,scores={level=11},distance=..3] unless score @n[type=marker,name=console] logs matches ..0 unless block -6 -61 136 stripped_dark_oak_log run function main:levels/level11/grow
