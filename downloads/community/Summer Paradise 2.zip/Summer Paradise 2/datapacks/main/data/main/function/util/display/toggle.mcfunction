execute as @e[type=marker,name=console,tag=sidebar_level] run tag @s add remove_sidebar_level
execute as @e[type=marker,name=console] run tag @s add sidebar_level
execute as @e[type=marker,name=console,tag=remove_sidebar_level] run tag @s remove sidebar_level
execute as @e[type=marker,name=console,tag=remove_sidebar_level] run tag @s remove remove_sidebar_level

execute unless entity @e[type=marker,name=console,tag=sidebar_level] run function time:display/sidebar/toggle_time
execute if entity @e[type=marker,name=console,tag=sidebar_level] run function time:display/sidebar/toggle_level

execute unless entity @e[type=marker,name=console,tag=sidebar_level] run data merge entity @n[x=-3,y=-40,z=4,distance=..2,tag=option_display] {text:{text:"Time",bold:true,color:green}}
execute if entity @e[type=marker,name=console,tag=sidebar_level] run data merge entity @n[x=-3,y=-40,z=4,distance=..2,tag=option_display] {text:{text:"Level",bold:true,color:green}}