schedule function main:tick_10 10t

effect give @a saturation infinite 10 true
execute as @a run attribute @s minecraft:burning_time base set 0.001

#spawnpoint
spawnpoint @a 0 -40 0 0 0
spawnpoint @a[scores={level=1}] 20 -62 110 90 30
spawnpoint @a[scores={level=2}] 13 -48 113 145 30
spawnpoint @a[scores={level=3}] -1 -40 115 90 30
spawnpoint @a[scores={level=4}] -23 -42 115 135 30
spawnpoint @a[scores={level=5}] -27 -49 121 0 30
spawnpoint @a[scores={level=6}] -16 -44 130 270 30
spawnpoint @a[scores={level=7}] 2 -36 121 -110 30
spawnpoint @a[scores={level=8}] 19 -48 123 270 30
spawnpoint @a[scores={level=9}] 29 -43 134 15 30
spawnpoint @a[scores={level=10}] 13 -42 149 90 30
spawnpoint @a[scores={level=11}] -2 -46 136 90 30
spawnpoint @a[scores={level=12}] -19 -43 137 90 30
spawnpoint @a[scores={level=13}] -32 -44 155 0 30
spawnpoint @a[scores={level=14}] -13 -48 166 270 30
spawnpoint @a[scores={level=15}] 2 -48 161 -135 30
spawnpoint @a[scores={level=16},tag=!elytra,tag=!end] 21 -42 165 -110 30
spawnpoint @a[tag=elytra] 25 31 158 -60 0
spawnpoint @a[tag=end] 106 -29 290 180 0

#kill items
execute as @e[type=item] unless items entity @s contents *[minecraft:custom_data~{"hielkemaps:stay":true}] run kill