effect give @a[x=-7,y=-47,z=127,dx=0,dy=5,dz=0] levitation 1 3 true
effect clear @a[x=-7,y=-39,z=127,dx=0,dy=1,dz=0] levitation
particle minecraft:end_rod -7 -45 127 0.2 2 0.2 0 1