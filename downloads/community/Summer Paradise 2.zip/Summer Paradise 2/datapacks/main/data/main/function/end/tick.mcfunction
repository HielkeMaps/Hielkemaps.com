#end detection
execute as @a[tag=ingame,x=106,y=-36,z=290,distance=..10,gamemode=!spectator] run function time:finish
execute as @a[x=106,y=-36,z=290,distance=..10,gamemode=!spectator,nbt={OnGround:1b}] run clear @s elytra

#end tag
tag @a[x=106,y=-36,z=290,distance=..10,gamemode=!spectator] add end
spawnpoint @a[tag=end,x=106,y=-36,z=290,distance=..10,gamemode=!spectator] 106 -29 290 180 0
execute as @a[tag=end,gamemode=!spectator] at @s if block ~ ~ ~ water run function main:tp/to_end

#back to spawn portal
execute as @a[x=105,y=-36,z=302,dx=2,dy=2,dz=0] run function main:tp/to_spawn