schedule function main:tick_2 2t replace

#spawn
execute as @a[x=-1,y=-40,z=7,dx=2,dy=2,dz=0] run function main:tp/to_start

execute as @a[tag=playsound_teleport] at @s run playsound minecraft:entity.enderman.teleport master @s
tag @a remove playsound_teleport

execute as @a[gamemode=!spectator,tag=!inspace] run function main:setlevel

#On join
execute as @a[tag=!joined] run function main:on_join

#end
function main:end/tick

function main:util/elytra/tick

#kill in water outside map
execute as @a[gamemode=adventure,tag=!training_mode] at @s unless entity @s[x=-34,y=-48,z=100,dx=68,dy=0,dz=68] if block ~ ~ ~ water run kill @s[y=-48,dy=0]

#reset trigger
scoreboard players enable @a reset
scoreboard players set @a[tag=inRace] reset 0
tag @a[scores={reset=1}] remove joined
scoreboard players set @a reset 0

#restart trigger
scoreboard players enable @a restart
scoreboard players set @a[tag=inRace] restart 0
execute as @a[scores={restart=1}] run function main:restart
scoreboard players set @a restart 0