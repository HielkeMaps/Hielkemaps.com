tp @s 106 -37 280 0 30
tag @s add playsound_teleport