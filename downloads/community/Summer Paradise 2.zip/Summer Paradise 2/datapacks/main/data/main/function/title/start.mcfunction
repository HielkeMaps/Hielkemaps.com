scoreboard players add @s title_start 1
title @s[scores={title_start=10}] times 0 120 20

title @s[scores={title_start=10}] title {text:" "}
title @s[scores={title_start=10}] subtitle {text:"S"}
playsound minecraft:block.note_block.hat master @s[scores={title_start=10}] ~ ~ ~ 0.1 2

title @s[scores={title_start=14}] subtitle {text:"Su"}
playsound minecraft:block.note_block.hat master @s[scores={title_start=14}] ~ ~ ~ 0.1 2

title @s[scores={title_start=17}] subtitle {text:"Sum"}
playsound minecraft:block.note_block.hat master @s[scores={title_start=17}] ~ ~ ~ 0.1 2

title @s[scores={title_start=20}] subtitle {text:"Summ"}
playsound minecraft:block.note_block.hat master @s[scores={title_start=20}] ~ ~ ~ 0.1 2

title @s[scores={title_start=23}] subtitle {text:"Summe"}
playsound minecraft:block.note_block.hat master @s[scores={title_start=23}] ~ ~ ~ 0.1 2

title @s[scores={title_start=26}] subtitle {text:"Summer"}
playsound minecraft:block.note_block.hat master @s[scores={title_start=26}] ~ ~ ~ 0.1 2

title @s[scores={title_start=30}] subtitle {text:"Summer "}

title @s[scores={title_start=33}] subtitle {text:"Summer P"}
playsound minecraft:block.note_block.hat master @s[scores={title_start=33}] ~ ~ ~ 0.1 2

title @s[scores={title_start=36}] subtitle {text:"Summer Pa"}
playsound minecraft:block.note_block.hat master @s[scores={title_start=36}] ~ ~ ~ 0.1 2

title @s[scores={title_start=39}] subtitle {text:"Summer Par"}
playsound minecraft:block.note_block.hat master @s[scores={title_start=39}] ~ ~ ~ 0.1 2

title @s[scores={title_start=42}] subtitle {text:"Summer Para"}
playsound minecraft:block.note_block.hat master @s[scores={title_start=42}] ~ ~ ~ 0.1 2

title @s[scores={title_start=45}] subtitle {text:"Summer Parad"}
playsound minecraft:block.note_block.hat master @s[scores={title_start=45}] ~ ~ ~ 0.1 2

title @s[scores={title_start=48}] subtitle {text:"Summer Paradi"}
playsound minecraft:block.note_block.hat master @s[scores={title_start=48}] ~ ~ ~ 0.1 2

title @s[scores={title_start=51}] subtitle {text:"Summer Paradis"}
playsound minecraft:block.note_block.hat master @s[scores={title_start=51}] ~ ~ ~ 0.1 2

title @s[scores={title_start=54}] subtitle {text:"Summer Paradise"}
playsound minecraft:block.note_block.hat master @s[scores={title_start=54}] ~ ~ ~ 0.1 2

title @s[scores={title_start=57}] subtitle {text:"Summer Paradise "}

title @s[scores={title_start=72}] subtitle [{text:"Summer Paradise "},{text:"2",bold:true,color:"yellow"}]
playsound minecraft:entity.player.levelup master @s[scores={title_start=72}] ~ ~-2 ~ 100000 0.5

effect clear @s[scores={title_start=110}] slow_falling
tag @s[scores={title_start=110}] remove title_start
scoreboard players reset @s[scores={title_start=110}] title_start