execute as @a[scores={level=13},nbt={OnGround:1b}] at @s if block ~0.2999 ~-0.2 ~0.2999 minecraft:iron_block run effect give @s minecraft:slow_falling 3 0 false
execute as @a[scores={level=13},nbt={OnGround:1b}] at @s if block ~-0.2999 ~-0.2 ~0.2999 minecraft:iron_block run effect give @s minecraft:slow_falling 3 0 false
execute as @a[scores={level=13},nbt={OnGround:1b}] at @s if block ~0.2999 ~-0.2 ~-0.2999 minecraft:iron_block run effect give @s minecraft:slow_falling 3 0 false
execute as @a[scores={level=13},nbt={OnGround:1b}] at @s if block ~-0.2999 ~-0.2 ~-0.2999 minecraft:iron_block run effect give @s minecraft:slow_falling 3 0 false

execute as @a[scores={level=13},nbt={OnGround:1b},tag=!iron] at @s if block ~0.2999 ~-0.2 ~0.2999 minecraft:iron_block run playsound minecraft:entity.breeze.shoot master @s ~ ~ ~
execute as @a[scores={level=13},nbt={OnGround:1b},tag=!iron] at @s if block ~-0.2999 ~-0.2 ~0.2999 minecraft:iron_block run playsound minecraft:entity.breeze.shoot master @s ~ ~ ~
execute as @a[scores={level=13},nbt={OnGround:1b},tag=!iron] at @s if block ~0.2999 ~-0.2 ~-0.2999 minecraft:iron_block run playsound minecraft:entity.breeze.shoot master @s ~ ~ ~
execute as @a[scores={level=13},nbt={OnGround:1b},tag=!iron] at @s if block ~-0.2999 ~-0.2 ~-0.2999 minecraft:iron_block run playsound minecraft:entity.breeze.shoot master @s ~ ~ ~

execute as @a[scores={level=13},nbt={OnGround:1b}] at @s if block ~0.2999 ~-0.2 ~0.2999 minecraft:iron_block run tag @s add iron
execute as @a[scores={level=13},nbt={OnGround:1b}] at @s if block ~-0.2999 ~-0.2 ~0.2999 minecraft:iron_block run tag @s add iron
execute as @a[scores={level=13},nbt={OnGround:1b}] at @s if block ~0.2999 ~-0.2 ~-0.2999 minecraft:iron_block run tag @s add iron
execute as @a[scores={level=13},nbt={OnGround:1b}] at @s if block ~-0.2999 ~-0.2 ~-0.2999 minecraft:iron_block run tag @s add iron


execute as @a[scores={level=13},nbt={OnGround:1b},tag=!iron_slowfalling] at @s unless entity @s[x=-24,y=-42,z=156,dx=0,dy=0,dz=0] unless block ~0.2999 ~-0.2 ~0.2999 minecraft:iron_block unless block ~-0.2999 ~-0.2 ~0.2999 minecraft:iron_block unless block ~0.2999 ~-0.2 ~-0.2999 minecraft:iron_block unless block ~-0.2999 ~-0.2 ~-0.2999 minecraft:iron_block run effect clear @s minecraft:slow_falling
execute as @a[scores={level=13},nbt={OnGround:1b},tag=!iron_slowfalling] at @s unless entity @s[x=-24,y=-42,z=156,dx=0,dy=0,dz=0] unless block ~0.2999 ~-0.2 ~0.2999 minecraft:iron_block unless block ~-0.2999 ~-0.2 ~0.2999 minecraft:iron_block unless block ~0.2999 ~-0.2 ~-0.2999 minecraft:iron_block unless block ~-0.2999 ~-0.2 ~-0.2999 minecraft:iron_block run tag @s remove iron

#slow falling effect for 1 extra tick to make up for headhitter timing
tag @a remove iron_slowfalling
execute as @a[scores={level=13},nbt={OnGround:1b}] at @s if block ~0.2999 ~-0.2 ~0.2999 minecraft:iron_block run tag @s add iron_slowfalling
execute as @a[scores={level=13},nbt={OnGround:1b}] at @s if block ~-0.2999 ~-0.2 ~0.2999 minecraft:iron_block run tag @s add iron_slowfalling
execute as @a[scores={level=13},nbt={OnGround:1b}] at @s if block ~0.2999 ~-0.2 ~-0.2999 minecraft:iron_block run tag @s add iron_slowfalling
execute as @a[scores={level=13},nbt={OnGround:1b}] at @s if block ~-0.2999 ~-0.2 ~-0.2999 minecraft:iron_block run tag @s add iron_slowfalling

#particles
particle spore_blossom_air -25 -45 160 4 8 4 1 1 normal

#kill zone
execute as @a[scores={level=13}] at @s if entity @s[x=-33,y=-62,z=152,dx=15,dy=-68,dz=15] run damage @s 5 out_of_world
