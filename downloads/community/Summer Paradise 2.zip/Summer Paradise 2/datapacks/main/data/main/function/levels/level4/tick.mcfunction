#levitation
effect give @a[x=-24,y=-56,z=107,dx=0,dy=17,dz=0] levitation 1 5 true
effect clear @a[x=-24,y=-36,z=107,dx=0,dy=1,dz=0] levitation
particle minecraft:end_rod -24 -47 107 0.2 5 0.2 0 1

#portal
execute positioned -26.0 -62 102.0 as @a[dx=0,dy=1,dz=0] run tag @s add playsound_teleport
execute positioned -26.0 -62 102.0 as @a[dx=0,dy=1,dz=0] run tp @s -9 -58 110 150 ~