#wind charge
execute at @e[type=item,tag=wind_charge] as @a[distance=..1] unless items entity @s hotbar.* minecraft:wind_charge unless items entity @s inventory.* minecraft:wind_charge unless items entity @s weapon.* minecraft:wind_charge unless items entity @s player.cursor minecraft:wind_charge unless items entity @s player.crafting.* minecraft:wind_charge run give @s minecraft:wind_charge[use_cooldown={seconds:5}]
execute as @a unless entity @s[scores={level=1}] run clear @s minecraft:wind_charge

#copper golem
execute unless entity @a[scores={level=1}] run scoreboard players set @e[type=marker,name=console] copper_golem 1
execute if entity @a[scores={level=1}] run scoreboard players add @e[type=marker,name=console] copper_golem 1
scoreboard players set @e[type=marker,name=console,scores={copper_golem=200..}] copper_golem 0

execute if entity @e[type=marker,name=console,scores={copper_golem=0}] run data remove block 18 -58 122 Items
execute if entity @e[type=marker,name=console,scores={copper_golem=0}] run data merge block 16 -58 121 {Items:[{Slot:0b,id:"minecraft:copper_pickaxe"}]}