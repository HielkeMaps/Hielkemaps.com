tp @s 0 -40 0 0 0
tag @s add playsound_teleport

function time:reset

tag @s remove end
effect clear @s
clear @s *[minecraft:custom_data~{"hielkemaps:item":true},!minecraft:custom_data~{"tm:item":true}]