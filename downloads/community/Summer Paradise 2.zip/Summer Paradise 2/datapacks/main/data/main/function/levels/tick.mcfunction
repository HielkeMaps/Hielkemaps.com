function main:levels/level1/tick
function main:levels/level3/tick
function main:levels/level4/tick
function main:levels/level6/tick
function main:levels/level11/tick
function main:levels/level13/tick
function main:levels/level16/tick

#iron slow falling reset sound effect
execute as @a unless entity @s[scores={level=13}] run tag @s remove iron