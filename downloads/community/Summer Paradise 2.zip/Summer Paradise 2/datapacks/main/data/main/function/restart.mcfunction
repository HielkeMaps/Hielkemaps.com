tp @s 0 -40 4 0 0
gamemode adventure @s
tag @s remove ingame
scoreboard players reset @s level
scoreboard players reset @s level_display

function time:reset

tag @s remove end
effect clear @s
clear @s *[minecraft:custom_data~{"hielkemaps:item":true},!minecraft:custom_data~{"tm:item":true}]