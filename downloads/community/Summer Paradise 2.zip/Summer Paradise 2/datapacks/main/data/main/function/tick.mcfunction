function main:levels/tick
function main:util/display/tick

execute as @a[tag=title_start] at @s run function main:title/start

#spawn pk
execute positioned 7.0 -61 10.0 as @a[dx=0,dy=1,dz=0] at @s run tag @s add playsound_teleport
execute positioned 7.0 -61 10.0 as @a[dx=0,dy=1,dz=0] at @s run tp @s -3 -59 11 145 ~