item replace entity @s armor.chest with elytra[item_name={color:"yellow",fallback:"Elytra",translate:"item.minecraft.elytra"},unbreakable={},custom_data={"hielkemaps:item":true},enchantments={"minecraft:binding_curse":1,"minecraft:vanishing_curse":1},tooltip_display={hidden_components:[enchantments]}] 1
tag @s add elytra
playsound item.armor.equip_elytra master @s ~ ~ ~ 100 1 1
title @s actionbar {text:"You equipped Elytra",color:"gold",bold:true}