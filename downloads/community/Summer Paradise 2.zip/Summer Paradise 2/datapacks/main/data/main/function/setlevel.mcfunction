scoreboard players set @s[x=18,y=-63,z=101,dx=15,dy=1000,dz=15] level 1
scoreboard players set @s[x=1,y=-49,z=101,dx=15,dy=1000,dz=15] level 2
scoreboard players set @s[x=-16,y=-49,z=101,dx=15,dy=1000,dz=15] level 3
scoreboard players set @s[x=-33,y=-63,z=101,dx=15,dy=1000,dz=15] level 4
scoreboard players set @s[x=-33,y=-49,z=118,dx=15,dy=1000,dz=15] level 5
scoreboard players set @s[x=-16,y=-51,z=118,dx=15,dy=1000,dz=15] level 6
scoreboard players set @s[x=1,y=-51,z=118,dx=15,dy=1000,dz=15] level 7
scoreboard players set @s[x=18,y=-51,z=118,dx=15,dy=1000,dz=15] level 8
scoreboard players set @s[x=18,y=-63,z=135,dx=15,dy=1000,dz=15] level 9
execute unless entity @s[x=0,y=-55,z=134,dx=3,dy=5,dz=8] run scoreboard players set @s[x=1,y=-64,z=135,dx=15,dy=1000,dz=15] level 10
scoreboard players set @s[x=-16,y=-63,z=135,dx=15,dy=1000,dz=15] level 11
scoreboard players set @s[x=-33,y=-63,z=135,dx=15,dy=1000,dz=15] level 12
scoreboard players set @s[x=-33,y=-63,z=152,dx=15,dy=1000,dz=15] level 13
scoreboard players set @s[x=-16,y=-63,z=152,dx=15,dy=1000,dz=15] level 14
scoreboard players set @s[x=1,y=-63,z=152,dx=15,dy=1000,dz=15] level 15
scoreboard players set @s[x=18,y=-63,z=152,dx=15,dy=1000,dz=15] level 16