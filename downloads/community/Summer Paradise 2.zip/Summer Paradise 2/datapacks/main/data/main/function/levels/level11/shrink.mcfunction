scoreboard players set @n[type=marker,name=console] logs -40
fill -6 -60 136 -6 -61 136 air destroy
