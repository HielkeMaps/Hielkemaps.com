attribute @s minecraft:burning_time base set 0.001

tp @s 0 -40 0 0 0
gamemode adventure @s
tag @s remove ingame
function time:reset
scoreboard players reset @s level
scoreboard players reset @s level_display

tag @s remove end
effect clear @s

clear @s *[minecraft:custom_data~{"hielkemaps:item":true}]
execute as @s[tag=training_mode] run function trainingmode:leave

tag @s add joined