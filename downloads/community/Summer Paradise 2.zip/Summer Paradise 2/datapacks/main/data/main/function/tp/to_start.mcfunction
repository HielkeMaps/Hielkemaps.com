tag @s remove end
effect clear @s
clear @s *[minecraft:custom_data~{"hielkemaps:item":true},!minecraft:custom_data~{"tm:item":true}]

tp @s 26.0 25 109.0 45 20
tag @s add playsound_teleport

effect give @s[gamemode=!spectator] slow_falling infinite 10 true
execute as @s[tag=!inRace,gamemode=!spectator] run function time:start
tag @s[gamemode=!spectator] add title_start