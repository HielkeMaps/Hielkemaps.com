scoreboard players set @n[type=marker,name=console] logs -40
fill -6 -61 136 -6 -60 136 stripped_dark_oak_log
playsound block.wood.place block @a[distance=..12] -6 -61 136
playsound block.wood.place block @a[distance=..12] -6 -60 136
