# Generated from main on_join, without the lines that reset progress
attribute @s minecraft:burning_time base set 0.001
tp @s 0 53 -68 0 1
spawnpoint @s 0 53 -68
gamemode adventure @s
tag @s remove ingame
tag @s remove water_damage
function time:reset
clear @s *[minecraft:custom_data~{"hielkemaps:item":true}]
execute as @s[tag=training_mode] run function trainingmode:leave
