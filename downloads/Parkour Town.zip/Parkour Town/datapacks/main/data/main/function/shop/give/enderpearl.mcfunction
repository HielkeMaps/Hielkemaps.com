scoreboard players set @s drop_pearl 0
clear @s ender_pearl[minecraft:custom_data={shopItem:true}]
give @s ender_pearl[enchantment_glint_override=true,item_name={translate:"item.minecraft.ender_pearl",color:"light_purple",bold:true},lore=[{text:"Can only be used once per game",color:"gray",italic:false}],custom_data={shopItem:true}] 1