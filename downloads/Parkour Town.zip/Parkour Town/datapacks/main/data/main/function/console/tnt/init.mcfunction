data merge entity @s {fuse:20s}
tag @s add init