spawnpoint @s 0 52 -14
tp @s 0 52 -14 0 10
gamemode adventure @s
tag @s remove ingame

function time:reset

tag @s remove water_damage

#trident
tag @s remove trident_trigger

clear @s *[minecraft:custom_data~{"hielkemaps:item":true},!minecraft:custom_data~{"tm:item":true}]