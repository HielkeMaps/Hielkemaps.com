clear @s minecraft:tnt[minecraft:custom_data={shopItem:true}]
give @s tnt[item_name={translate:"block.minecraft.tnt",color:"red",bold:true},lore=[{text:"Blow up new pathways!",color:"gray",italic:false}],can_place_on={blocks:["minecraft:redstone_block"]},custom_data={shopItem:true}]
tag @s remove give_tnt