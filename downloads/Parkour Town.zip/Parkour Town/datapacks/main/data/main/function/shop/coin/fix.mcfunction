clear @s minecraft:sunflower[minecraft:custom_data={coin:true}]

give @s[scores={current_coins=1}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 1
give @s[scores={current_coins=2}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 2
give @s[scores={current_coins=3}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 3
give @s[scores={current_coins=4}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 4
give @s[scores={current_coins=5}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 5
give @s[scores={current_coins=6}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 6
give @s[scores={current_coins=7}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 7
give @s[scores={current_coins=8}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 8
give @s[scores={current_coins=9}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 9
give @s[scores={current_coins=10}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 10
give @s[scores={current_coins=11}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 11
give @s[scores={current_coins=12}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 12
give @s[scores={current_coins=13}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 13
give @s[scores={current_coins=14}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 14
give @s[scores={current_coins=15}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 15
give @s[scores={current_coins=16}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 16
give @s[scores={current_coins=17}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 17
give @s[scores={current_coins=18}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 18
give @s[scores={current_coins=19}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 19
give @s[scores={current_coins=20..}] sunflower[item_name={text:"Coin",color:"yellow",bold:true},custom_data={coin:true}] 20
scoreboard players set @s[scores={coins_found=21..}] coins_found 20

#when cheating in coins at the shop, current coins get get below 0, if so reset to 0
scoreboard players set @s[scores={current_coins=..0}] current_coins 0