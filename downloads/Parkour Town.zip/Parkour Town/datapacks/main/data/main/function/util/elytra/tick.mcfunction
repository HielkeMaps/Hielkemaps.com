execute as @a[x=7,y=312,z=8,dx=0,dy=0,dz=0,gamemode=!spectator] unless items entity @s armor.chest minecraft:elytra at @s run function main:util/elytra/pickup_fireworks
execute as @a[x=30,y=38,z=27,dx=0,dy=0,dz=0,gamemode=!spectator] unless items entity @s armor.chest minecraft:elytra at @s run function main:util/elytra/pickup

execute as @a[gamemode=!spectator] if items entity @s armor.chest minecraft:elytra[custom_data~{fireworks:true}] run item replace entity @s hotbar.4 with firework_rocket[custom_data={"hielkemaps:item":true}] 1