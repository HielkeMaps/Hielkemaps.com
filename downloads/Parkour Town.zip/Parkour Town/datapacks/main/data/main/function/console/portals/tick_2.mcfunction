execute if block 1 86 7 nether_portal run function main:console/portals/1/tick
execute if block -5 144 -8 nether_portal run function main:console/portals/2/tick
execute if block 16 252 10 nether_portal run function main:console/portals/3/tick
execute if block 17 291 1 nether_portal run function main:console/portals/4/tick
execute if block 15 182 2 nether_portal run function main:console/portals/5/tick
execute if block 7 52 3 nether_portal run function main:console/portals/6/tick
execute if block -28 124 21 nether_portal run function main:console/portals/7/tick