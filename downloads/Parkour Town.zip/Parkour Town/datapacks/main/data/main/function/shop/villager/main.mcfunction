#summon new villager (multiplayer support)

execute positioned -8.5 53.0 -67.5 rotated as @s run function main:shop/villager/summon

#disable colllision
team join villager @e[type=minecraft:villager]

#hide current without making player exit GUI
#this makes the villager super tiny and fly up to get out of the way
#super dumb but tping causes the GUI to close (1.21.3)
attribute @s minecraft:scale base set 0.01
attribute @s minecraft:gravity base set -0.08
data merge entity @s {Silent:1b}
effect give @s invisibility infinite 1 true
tag @s add kill_timer

#mark already bought trades as sold out
#this has to target the villager we just summoned, not @s: @s is the one being
#retired above, so anything set on it dies with it and the next shop visit is fresh
execute as @e[type=villager,tag=!kill_timer,limit=1,sort=nearest] run function main:shop/villager/sold_out