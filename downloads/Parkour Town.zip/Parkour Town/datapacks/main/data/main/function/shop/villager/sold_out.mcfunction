#run as the villager that is currently standing at the shop, positioned at the shopper
#sets every trade either way so it can be re-run at any time to resync, including after a reset
execute if score @p has_bell matches 1.. run data modify entity @s Offers.Recipes[0].uses set value 1
execute unless score @p has_bell matches 1.. run data modify entity @s Offers.Recipes[0].uses set value 0

execute if score @p has_boots matches 1.. run data modify entity @s Offers.Recipes[1].uses set value 1
execute unless score @p has_boots matches 1.. run data modify entity @s Offers.Recipes[1].uses set value 0

execute if score @p has_flint matches 1.. run data modify entity @s Offers.Recipes[2].uses set value 1
execute unless score @p has_flint matches 1.. run data modify entity @s Offers.Recipes[2].uses set value 0

execute if score @p has_tnt matches 1.. run data modify entity @s Offers.Recipes[3].uses set value 1
execute unless score @p has_tnt matches 1.. run data modify entity @s Offers.Recipes[3].uses set value 0

execute if score @p has_enderpearl matches 1.. run data modify entity @s Offers.Recipes[4].uses set value 1
execute unless score @p has_enderpearl matches 1.. run data modify entity @s Offers.Recipes[4].uses set value 0

execute if score @p has_trident matches 1.. run data modify entity @s Offers.Recipes[5].uses set value 1
execute unless score @p has_trident matches 1.. run data modify entity @s Offers.Recipes[5].uses set value 0
