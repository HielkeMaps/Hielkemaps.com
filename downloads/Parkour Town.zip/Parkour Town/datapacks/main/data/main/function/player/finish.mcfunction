tag @s remove bottom
spawnpoint @s 7 320 3 180 0
function time:finish