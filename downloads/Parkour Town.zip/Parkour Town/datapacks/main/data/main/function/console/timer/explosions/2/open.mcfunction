clone -8 -10 -10 -12 -6 -7 17 156 -7
particle block{block_state:{id:"minecraft:red_sandstone"}} 19 158 -4 1.5 1.5 1.5 1 100

tag @e[type=marker,name=console,limit=1] add explosion2_timer