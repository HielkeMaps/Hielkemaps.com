function main:shop/buy/main
scoreboard players set @s has_bell 1
scoreboard players remove @s current_coins 2

clear @s bell[minecraft:custom_data={shopItem:true}] 1

tellraw @s [{text:"[Shop] ",color:"yellow",bold:true},{text:"Purchased ",bold:false,color:"gray"},{text:"[",color:"yellow",bold: false},{text:"Noisy Coins",color:"yellow",bold: true,hover_event:{action:"show_text",value:{text:"Undiscovered coins will make a sound\nwhen crouching, making it easier to find them!",color:"gray"}}},{text:"]",color:"yellow",bold: false}]