clone -22 -10 1 -27 -8 5 -2 275 9

particle block{block_state:{id:"minecraft:moss_block"}} 0 276 11 1.5 1.5 1.5 1 200

tag @e[type=marker,name=console,limit=1] add explosion7_timer