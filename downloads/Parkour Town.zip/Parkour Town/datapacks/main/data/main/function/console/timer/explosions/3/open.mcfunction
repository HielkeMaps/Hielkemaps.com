clone -22 -10 -10 -26 -5 -6 11 166 1

particle block{block_state:{Name:"minecraft:snow"}} 13 168 3 1.5 1.5 1.5 1 50
particle block{block_state:{Name:"minecraft:stone"}} 13 168 3 1.5 1.5 1.5 1 50

tag @e[type=marker,name=console,limit=1] add explosion3_timer