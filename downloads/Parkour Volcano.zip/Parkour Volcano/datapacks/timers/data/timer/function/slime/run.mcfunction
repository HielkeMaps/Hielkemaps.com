scoreboard players add @s timer_slime 1

execute as @s[scores={timer_slime=2}] positioned -64 209 153 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=2}] positioned -66 209 155 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=2}] positioned -67 209 156 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=2}] positioned -65 209 153 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=3}] positioned -65 209 155 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=3}] positioned -64 209 154 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=3}] positioned -63 209 153 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=3}] positioned -67 209 157 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=3}] positioned -63 209 152 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=3}] positioned -64 209 152 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=3}] positioned -66 209 154 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=3}] positioned -67 209 154 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=4}] positioned -63 209 154 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=4}] positioned -62 209 152 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=4}] positioned -65 209 154 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=4}] positioned -62 209 151 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=4}] positioned -67 209 155 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=4}] positioned -68 209 156 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=4}] positioned -66 209 153 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=4}] positioned -65 209 152 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=5}] positioned -63 209 155 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=5}] positioned -61 209 153 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=5}] positioned -66 209 156 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=5}] positioned -68 209 157 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=5}] positioned -63 209 151 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=5}] positioned -65 209 151 run function timer:slime/setblock/slime_block
execute as @s[scores={timer_slime=6}] positioned -63 209 150 run function timer:slime/setblock/slime_block

execute as @s[scores={timer_slime=6}] run function timer:slime/reset
