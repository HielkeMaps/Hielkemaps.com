schedule function timer:tick_2 2t
execute as @e[type=marker,name=console,limit=1] unless score @s timer_froglight matches -1 run function timer:froglight/run
