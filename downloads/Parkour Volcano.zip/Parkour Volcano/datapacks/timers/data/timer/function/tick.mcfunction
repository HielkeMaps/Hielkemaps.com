execute as @e[type=marker,name=console,limit=1] unless score @s timer_slime matches -1 run function timer:slime/run
