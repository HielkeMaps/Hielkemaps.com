# Summons a hologram with the rank times and the nearest player's PB: /function time:hologram/summon
summon text_display ~ ~ ~ {Tags:["time_hologram"],billboard:"vertical",alignment:"left",line_width:200,shadow:1b,background:0}
execute as @e[type=text_display,tag=time_hologram,distance=..0.01,limit=1] run function time:hologram/refresh
