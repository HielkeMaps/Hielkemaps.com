# Removes holograms within 3 blocks: /function time:hologram/remove
kill @e[type=text_display,tag=time_hologram,distance=..3]
