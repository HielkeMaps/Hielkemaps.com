$data modify storage time:hologram $(key) set value "$(h):$(mp)$(m):$(sp)$(s)"
