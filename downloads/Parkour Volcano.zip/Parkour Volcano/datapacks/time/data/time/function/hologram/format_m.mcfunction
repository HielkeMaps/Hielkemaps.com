$data modify storage time:hologram $(key) set value "$(m):$(sp)$(s)"
