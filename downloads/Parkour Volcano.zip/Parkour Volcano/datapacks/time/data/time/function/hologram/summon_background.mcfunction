# Same as time:hologram/summon, with a dark background (can look off in front of water): /function time:hologram/summon_background
summon text_display ~ ~ ~ {Tags:["time_hologram","time_hologram_bg"],billboard:"vertical",alignment:"left",line_width:200,shadow:1b,background:1275068416}
execute as @e[type=text_display,tag=time_hologram,distance=..0.01,limit=1] run function time:hologram/refresh
