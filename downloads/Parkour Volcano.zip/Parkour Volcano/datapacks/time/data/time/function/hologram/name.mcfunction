# Run as the hologram: with several players nearby, title the PB with the nearest player's name
data modify storage time:hologram pb_title set value "YOUR PB"
execute store result score #near temp at @s if entity @a[distance=..16]
execute unless score #near temp matches 2.. run return 0

# Text displays can't resolve selectors, so read the name from a player head
execute at @s run summon item_display ~ ~ ~ {Tags:["time_hologram_name"]}
execute at @s as @p[distance=..16] run loot replace entity @e[type=item_display,tag=time_hologram_name,limit=1,sort=nearest] contents loot {pools:[{rolls:1,entries:[{type:"minecraft:item",name:"minecraft:player_head",modifier:{type:"minecraft:fill_player_head",entity:"this"}}]}]}
execute at @s run data modify storage time:hologram name.name set from entity @e[type=item_display,tag=time_hologram_name,limit=1,sort=nearest] item.components."minecraft:profile".name
execute at @s run kill @e[type=item_display,tag=time_hologram_name,distance=..1]
execute if data storage time:hologram name.name run function time:hologram/name_title with storage time:hologram name
data remove storage time:hologram name
