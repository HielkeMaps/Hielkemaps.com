# Formats #fmt temp (seconds) as M:SS or H:MM:SS into storage time:hologram <key>
scoreboard players operation #h temp = #fmt temp
scoreboard players operation #h temp /= hour seconds
scoreboard players operation #m temp = #fmt temp
scoreboard players operation #m temp %= hour seconds
scoreboard players operation #m temp /= minute seconds
scoreboard players operation #s temp = #fmt temp
scoreboard players operation #s temp %= minute seconds

execute store result storage time:hologram fmt.h int 1 run scoreboard players get #h temp
execute store result storage time:hologram fmt.m int 1 run scoreboard players get #m temp
execute store result storage time:hologram fmt.s int 1 run scoreboard players get #s temp
data modify storage time:hologram fmt.mp set value ""
execute if score #h temp matches 1.. if score #m temp matches ..9 run data modify storage time:hologram fmt.mp set value "0"
data modify storage time:hologram fmt.sp set value ""
execute if score #s temp matches ..9 run data modify storage time:hologram fmt.sp set value "0"
$data modify storage time:hologram fmt.key set value "$(key)"
$execute store result storage time:hologram $(key)_sec int 1 run scoreboard players get #fmt temp

execute if score #h temp matches 1.. run return run function time:hologram/format_h with storage time:hologram fmt
function time:hologram/format_m with storage time:hologram fmt
