function main:volcano/time/pb/format
data modify storage time:hologram vpb set from storage main:volcano pb.line
data modify storage time:hologram vpb_color set value "yellow"
