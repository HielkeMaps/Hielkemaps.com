# Generated from main on_join, without the lines that reset progress
attribute @s minecraft:burning_time base set 0.001
tp @s 0 162 -1 0 0
spawnpoint @s 0 162 -1
gamemode adventure @s
clear @s *[minecraft:custom_data~{"hielkemaps:item":true}]
execute as @s[tag=training_mode] run function trainingmode:leave
tag @s remove ingame
tag @s remove has_scaffold
tag @s remove has_snowball
function time:reset
