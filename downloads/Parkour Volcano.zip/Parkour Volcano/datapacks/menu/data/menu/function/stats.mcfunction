scoreboard players operation #fmt temp = rank_s seconds
function time:hologram/format {key:"s"}
scoreboard players operation #fmt temp = rank_a seconds
function time:hologram/format {key:"a"}
scoreboard players operation #fmt temp = rank_b seconds
function time:hologram/format {key:"b"}
scoreboard players operation #fmt temp = rank_c seconds
function time:hologram/format {key:"c"}

# 2147483647 means no PB yet
data modify storage time:hologram pb_line set value "No PB yet"
data modify storage time:hologram pb_color set value "gray"
scoreboard players operation #fmt temp = @s time_pb
execute if score #fmt temp matches 1..2147483646 run function time:hologram/format {key:"pb"}
execute if score #fmt temp matches 1..2147483646 run data modify storage time:hologram pb_color set value "yellow"
execute if score #fmt temp matches 1..2147483646 run function time:hologram/pb_line with storage time:hologram

data modify storage time:hologram vpb set value "No PB yet"
data modify storage time:hologram vpb_color set value "gray"
execute if score @s volcano_time_pb matches 0.. run function menu:volcano_pb

function menu:stats_show with storage time:hologram
