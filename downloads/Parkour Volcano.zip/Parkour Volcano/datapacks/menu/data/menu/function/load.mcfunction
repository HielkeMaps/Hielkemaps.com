scoreboard objectives add menu trigger
scoreboard objectives add spawn trigger
scoreboard objectives modify menu displayname {text:"Menu",color:"yellow",bold:true}
scoreboard objectives modify spawn displayname {text:"Spawn",color:"yellow",bold:true}
