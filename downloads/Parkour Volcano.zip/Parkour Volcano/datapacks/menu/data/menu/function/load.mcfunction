scoreboard objectives add menu trigger
scoreboard objectives add spawn trigger
