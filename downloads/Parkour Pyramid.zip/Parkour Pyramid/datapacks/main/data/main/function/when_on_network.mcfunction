scoreboard players set #is_server temp 1
execute at @e[tag=frame_5] run setblock ~ ~2 ~ air
execute at @e[tag=frame_5] run setblock ^2 ^ ^ air
execute at @e[tag=frame_5] run setblock ^-2 ^ ^ air
kill @e[tag=more_maps]
data merge entity @e[type=text_display,tag=server,limit=1] {view_range:1}

#Parkour pyramid options
kill @e[tag=options]
setblock 9 82 12 air
setblock 9 82 14 air
gamerule show_death_messages false
gamerule send_command_feedback false
