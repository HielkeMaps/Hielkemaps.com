data merge entity @s {DisplayState:{id:""}}
tag @s remove tnt
playsound minecraft:entity.item.pickup master @a ~ ~ ~