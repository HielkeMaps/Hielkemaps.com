scoreboard players set @s bounceDeath 20
scoreboard players reset @s lvl5_killtimer
kill @s