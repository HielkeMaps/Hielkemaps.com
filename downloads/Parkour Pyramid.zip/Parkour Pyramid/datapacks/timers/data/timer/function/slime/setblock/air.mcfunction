setblock ~ ~ ~ air destroy
