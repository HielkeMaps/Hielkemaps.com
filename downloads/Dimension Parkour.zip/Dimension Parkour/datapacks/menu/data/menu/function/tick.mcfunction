scoreboard players enable @a menu
scoreboard players enable @a spawn
# /trigger menu opens the main page
execute as @a[scores={menu=1}] run dialog show @s menu:menu
execute as @a[scores={menu=10}] run function menu:stats
execute as @a[scores={menu=2}] run scoreboard players set @s training_mode 1
execute as @a[scores={menu=3}] run function time:pb/reset
execute as @a[scores={menu=3}] run function menu:stats
# Parkour Town only: main:triggers runs the shop reset
execute as @a[scores={menu=4}] run scoreboard players set @s reset_shop 1
execute as @a[scores={menu=4}] run dialog show @s menu:menu
execute as @a[scores={menu=8}] run function menu:teleport
# Teleports go through the restart, spawn (and teleport_volcano) triggers
execute as @a[scores={menu=6}] run scoreboard players set @s restart 1
execute as @a[scores={menu=7}] run scoreboard players set @s spawn 1
# Keep the dialog open until the map has handled the trigger: closing it returns to the pause screen, which pauses the server first
tag @a[scores={menu=6..7}] add menu_teleport
execute as @a[tag=menu_teleport] unless score @s restart matches 1.. unless score @s spawn matches 1.. run dialog clear @s
execute as @a[tag=menu_teleport] unless score @s restart matches 1.. unless score @s spawn matches 1.. run tag @s remove menu_teleport
# /trigger spawn, blocked during a race like restart and reset
scoreboard players set @a[tag=inRace] spawn 0
execute as @a[scores={spawn=1..}] at @s run function menu:spawn
scoreboard players set @a[scores={spawn=1..}] spawn 0
scoreboard players set @a[scores={menu=1..}] menu 0
