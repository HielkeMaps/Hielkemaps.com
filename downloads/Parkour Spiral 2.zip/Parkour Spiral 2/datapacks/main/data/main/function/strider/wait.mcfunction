scoreboard players add @s strider_wait 1

tag @s remove forth

#remove saddle
execute as @s[scores={strider_wait=10}] run data modify entity @s equipment.saddle set value {}
execute as @s[scores={strider_wait=10}] as @p if data entity @s RootVehicle at @s run tp ~1 ~0.5 ~

tag @s[scores={strider_wait=20..}] add back
tag @s[scores={strider_wait=20..}] remove wait_back

scoreboard players reset @s[scores={strider_wait=20..}] strider_wait