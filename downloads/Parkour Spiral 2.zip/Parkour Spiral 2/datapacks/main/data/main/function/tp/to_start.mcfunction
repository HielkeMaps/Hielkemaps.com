tp ~34 ~-108 ~1
spawnpoint @s -57 3 -2 315 0
tag @s add playsound_portal
scoreboard players set @s portal_timer 0