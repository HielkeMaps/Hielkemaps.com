tag @s remove back

data modify entity @s equipment.saddle set value {id:"minecraft:saddle"}
playsound minecraft:entity.strider.saddle neutral @a ~ ~ ~ 0.5

tag @s add waiting