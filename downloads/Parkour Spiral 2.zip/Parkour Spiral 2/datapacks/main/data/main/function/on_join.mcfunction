attribute @s minecraft:burning_time base set 0.001

tp @s -115 113 0 270 10
spawnpoint @s -115 113 0 270 0
gamemode adventure @s
tag @s remove ingame
function time:reset

tag @s add joined

clear @s *[minecraft:custom_data~{"hielkemaps:item":true}]
execute as @s[tag=training_mode] run function trainingmode:leave