tag @s remove forth
tag @s remove back
tag @s remove wait_back
scoreboard players reset @s strider_wait
data modify entity @s equipment.saddle set value {id:"minecraft:saddle"}
tag @s add waiting