#spawnpoint
spawnpoint @s 0 241 0 90 0

function time:finish