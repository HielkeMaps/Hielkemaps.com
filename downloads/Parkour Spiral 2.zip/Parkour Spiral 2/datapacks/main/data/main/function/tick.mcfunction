execute as @a at @s run function main:pressure_plate/set_score

#PLAYSOUNDS
execute as @a[tag=playsound_warp] at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 1
tag @a remove playsound_warp

execute as @a[tag=playsound_portal] at @s run playsound minecraft:block.portal.travel master @s ~ ~ ~ 0.5 1 1
tag @a remove playsound_portal

execute as @a[x=18,y=56,z=-1,dx=0,dy=1,dz=0] at @s run function main:tp/gateway

#timers
execute as @e[type=marker,name=console,limit=1] run function main:timer/tick

#striders at start
execute as @e[type=strider] at @s run function main:strider/tick