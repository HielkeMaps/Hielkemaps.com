scoreboard players add @s door_timer 1

execute as @s[scores={door_timer=1}] run setblock -10 4 12 minecraft:air

execute as @s[scores={door_timer=50}] run setblock -10 4 12 minecraft:redstone_block

tag @s[scores={door_timer=50}] remove door_timer
scoreboard players reset @s[scores={door_timer=50}] door_timer