#runs twice a second
schedule function main:tick_10 10t

effect give @a minecraft:saturation infinite 10 true

#kill items
execute as @e[type=item] unless items entity @s contents *[minecraft:custom_data~{"hielkemaps:stay":true}] run kill