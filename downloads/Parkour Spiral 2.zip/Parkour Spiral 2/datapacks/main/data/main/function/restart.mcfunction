spawnpoint @s -21 2 -1 315 0
tp @s -21 2 -1 315 10
gamemode adventure @s
tag @s remove ingame
function time:reset
clear @s *[minecraft:custom_data~{"hielkemaps:item":true},!minecraft:custom_data~{"tm:item":true}]