setblock ~ ~ ~ acacia_wood
setblock ~ ~1 ~ acacia_pressure_plate
playsound minecraft:block.piston.extend block @a ~ ~ ~