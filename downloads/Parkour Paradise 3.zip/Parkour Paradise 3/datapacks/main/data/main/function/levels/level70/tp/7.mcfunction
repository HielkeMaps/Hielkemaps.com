tp @s 65 60 992 225 10
tag @s add playsound_teleport