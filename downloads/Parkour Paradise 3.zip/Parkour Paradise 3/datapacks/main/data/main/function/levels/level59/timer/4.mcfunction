fill -100 39 959 -101 39 958 air
fill -100 38 958 -101 38 959 minecraft:sea_lantern
fill -100 37 958 -101 37 959 minecraft:blue_ice
function main:levels/level59/timer/on_level_change