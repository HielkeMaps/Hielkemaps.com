effect clear @s[x=51,y=61,z=1009,dx=2,dy=-22,dz=2] levitation
effect give @s[x=52,y=40,z=1010,dx=0,dy=18,dz=0] levitation 1 10 true

clear @s[x=60,y=21,z=1013,dx=10,dy=-12,dz=-10,predicate=main:is_onground] elytra[minecraft:custom_data~{"hielkemaps:item":true}]