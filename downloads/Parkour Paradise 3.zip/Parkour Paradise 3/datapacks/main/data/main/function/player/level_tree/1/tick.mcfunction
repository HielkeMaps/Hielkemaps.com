execute if score @s level matches ..26 run function main:player/level_tree/1/1/tick
execute if score @s level matches 28.. run function main:player/level_tree/1/2/tick