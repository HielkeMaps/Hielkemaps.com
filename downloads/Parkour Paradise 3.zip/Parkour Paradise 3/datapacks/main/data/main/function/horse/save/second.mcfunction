execute store result score @s saved_horse_2 run data get entity @s RootVehicle.Entity.UUID[0]
tag @s add set_riding_2