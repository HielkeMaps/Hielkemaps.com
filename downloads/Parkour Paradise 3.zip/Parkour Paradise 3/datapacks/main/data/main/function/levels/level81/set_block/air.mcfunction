setblock ~ ~ ~ air
playsound minecraft:block.piston.contract block @a ~ ~ ~