scoreboard players set @e[type=block_display,name=snake_99,tag=start,limit=1,scores={snake_99=-1}] snake_99 0
