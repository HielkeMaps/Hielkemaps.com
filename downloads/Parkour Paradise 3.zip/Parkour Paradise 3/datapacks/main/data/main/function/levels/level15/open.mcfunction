setblock -31 1 884 redstone_torch
setblock -32 1 884 redstone_torch