scoreboard players reset @s[x=30,y=38,z=1015,dx=19,dy=30,dz=19] lvl89_timer
scoreboard players add @s[x=30,y=29,z=1022,dx=12,dy=6,dz=-7] lvl89_timer 1