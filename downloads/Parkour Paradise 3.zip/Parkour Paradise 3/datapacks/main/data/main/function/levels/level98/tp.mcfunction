tag @s add playsound_teleport
tp @s -78 59 1054 90 10
execute at @s run particle splash ~ ~1 ~ 0.2 0.5 0.2 0 100