tp @s -31 23 997 270 0
tag @s add playsound_teleport