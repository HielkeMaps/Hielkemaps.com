effect give @s[x=-78,y=53,z=1008,dx=0,dy=6,dz=0] levitation 1 8 true

effect clear @s[x=-78,y=53,z=1007,dx=0,dy=2,dz=0] levitation
effect clear @s[x=-80,y=62,z=1010,dx=3,dy=2,dz=-3] levitation