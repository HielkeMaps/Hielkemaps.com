execute if score @s level matches ..42 run function main:player/level_tree/1/tick
execute if score @s level matches 47.. run function main:player/level_tree/2/tick