effect clear @s[x=25,y=45,z=969,dx=2,dy=12,dz=2] levitation
effect give @s[x=26,y=46,z=970,dx=0,dy=8,dz=0] levitation 1 5 true