execute if block -112 57 869 lever[powered=true] run function main:levels/level19/door/up
execute if block -112 57 869 lever[powered=false] run function main:levels/level19/door/down