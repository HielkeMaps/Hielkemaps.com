execute as @s[x=-5,y=17,z=948,dx=0,dy=1,dz=0] run function main:levels/level47/tp
execute as @s[x=4,y=16,z=932,dx=0,dy=1,dz=0] run function main:levels/level47/tp