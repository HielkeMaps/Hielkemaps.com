execute as @s[x=-4,y=45,z=953,dx=0,dy=1,dz=0] run function main:levels/level54/tp
execute as @s[x=7,y=55,z=971,dx=0,dy=1,dz=0] run function main:levels/level54/tp2