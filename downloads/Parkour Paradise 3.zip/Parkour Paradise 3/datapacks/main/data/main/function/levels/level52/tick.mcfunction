effect clear @s[x=40,y=30,z=969,dx=0,dy=3,dz=0] levitation
effect clear @s[x=38,y=59,z=970,dx=2,dy=5,dz=-2] levitation
effect give @s[x=39,y=30,z=969,dx=0,dy=28,dz=0] levitation 1 10 true