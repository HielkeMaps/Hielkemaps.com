scoreboard players set @e[type=block_display,name=snake_15,tag=start,limit=1,scores={snake_15=-1}] snake_15 0
