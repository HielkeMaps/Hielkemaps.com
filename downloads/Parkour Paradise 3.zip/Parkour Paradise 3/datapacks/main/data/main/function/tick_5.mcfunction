schedule function main:tick_5 5t

#snake
function main:snake/tick_5