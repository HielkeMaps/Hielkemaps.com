#level 71
execute as @s[x=51,y=40,z=1009,dx=2,dy=18,dz=2] run data merge entity @s {Motion:[0.3,0.3,0.0]}
execute as @s[x=51,y=58,z=1009,dx=2,dy=1,dz=2] run data merge entity @s {Motion:[0.3,0.3,0.0]}

#level 78
execute as @s[x=-91,y=59,z=1012,dx=0,dy=0,dz=-4] run data merge entity @s {Motion:[0.0,0.0,-0.06]}