schedule function main:tick_3 3t

#snake
function main:snake/tick_3