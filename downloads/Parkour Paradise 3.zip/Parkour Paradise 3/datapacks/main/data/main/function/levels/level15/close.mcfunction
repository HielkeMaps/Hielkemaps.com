setblock -31 1 884 stone
setblock -32 1 884 stone
tag @s remove lvl15_timer
scoreboard players set @s lvl15_timer 0