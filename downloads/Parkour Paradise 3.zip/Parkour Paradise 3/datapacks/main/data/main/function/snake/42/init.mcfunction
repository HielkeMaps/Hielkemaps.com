scoreboard players set @e[type=block_display,name=snake_42,tag=start,limit=1,scores={snake_42=-1}] snake_42 0
