execute at @s run particle minecraft:poof ~ ~1 ~ 0.2 0.2 0.2 0 10 
tp @s ~ -1000 ~