setblock -109 29 973 diamond_block destroy
fill -109 34 973 -109 35 973 air destroy