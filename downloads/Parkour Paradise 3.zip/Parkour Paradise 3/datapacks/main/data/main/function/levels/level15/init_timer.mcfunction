scoreboard players set @e[type=marker,name=console] lvl15_timer 0
tag @e[type=marker,name=console] add lvl15_timer