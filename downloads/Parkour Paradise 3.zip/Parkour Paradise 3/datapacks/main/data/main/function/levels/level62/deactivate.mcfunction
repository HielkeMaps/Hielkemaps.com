setblock -109 29 973 diamond_ore destroy
fill -109 34 973 -109 35 973 stone

tag @s remove lvl62_timer
scoreboard players reset @s lvl62_timer