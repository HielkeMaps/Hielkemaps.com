effect give @s levitation 3 10 true
tag @s add playsound_honey