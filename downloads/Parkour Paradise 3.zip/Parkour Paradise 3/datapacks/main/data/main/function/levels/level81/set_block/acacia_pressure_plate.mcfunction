setblock ~ ~ ~ air
setblock ~ ~-1 ~ acacia_pressure_plate