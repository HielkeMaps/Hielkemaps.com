execute if score @s level matches 47 run function main:levels/level47/tick
execute if score @s level matches 50 run function main:levels/level50/tick
execute if score @s level matches 51 run function main:levels/level51/tick
execute if score @s level matches 52 run function main:levels/level52/tick
execute if score @s level matches 53 run function main:levels/level53/tick