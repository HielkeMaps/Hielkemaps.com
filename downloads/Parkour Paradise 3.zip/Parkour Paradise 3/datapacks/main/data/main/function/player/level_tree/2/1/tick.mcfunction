execute if score @s level matches ..53 run function main:player/level_tree/2/1/1/tick
execute if score @s level matches 54.. run function main:player/level_tree/2/1/2/tick