execute if block -29 59 977 acacia_pressure_plate[powered=true] run function main:levels/level66/timer/init
function main:levels/level66/timer/tick