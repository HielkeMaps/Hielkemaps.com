tp @s 68 25 976 120 0
tag @s add playsound_teleport