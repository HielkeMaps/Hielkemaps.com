setblock -29 59 977 air destroy
tag @s add lvl66_timer