effect clear @s[x=-138,y=43,z=952,dx=2,dy=18,dz=2] levitation
effect give @s[x=-137,y=42,z=953,dx=0,dy=15,dz=0] levitation 2 7 true