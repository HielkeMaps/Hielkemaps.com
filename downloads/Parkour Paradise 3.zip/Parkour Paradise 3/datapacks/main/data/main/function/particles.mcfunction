#level 1
particle end_rod -127 50 863 0.25 3 0.25 0 4

#level 3
particle totem_of_undying -78 56 865 0.25 0.8 0.25 0.1 6

#level 6
particle end_rod -20.00 9.5 865.5 0.5 5 0.25 0 2
particle end_rod -20.00 19.5 865.5 0.5 5 0.25 0 2
particle end_rod -20.00 29.5 865.5 0.5 5 0.25 0 2
particle end_rod -20.00 39.5 865.5 0.5 5 0.25 0 2
particle end_rod -20.00 49.5 865.5 0.5 5 0.25 0 2

#level 9
particle portal 50.5 24.3 856.00 0 1 1 0 20

#level 10
particle end_rod 69.0 35 849.00 0.5 2 0.5 0 2
particle end_rod 69.0 39 849.00 0.5 2 0.5 0 2
particle end_rod 69.0 43 849.00 0.5 2 0.5 0 2

#level 15
particle note -15.5 30 868.5 0 1 0.2 1 2
particle note -15.5 33 868.5 0 1 0.2 1 2

#level 17
particle end_rod -57 41 869 0.23 3 0.23 0 2
particle end_rod -57 52 869 0.23 3 0.23 0 2

#level 26
particle end_rod -31 40 906 0.25 3 0.25 0 2
particle end_rod -31 50 906 0.25 3 0.25 0 2

#level 28
particle end_rod 11 46 904 0.25 3 0.25 0 2

#level 34
particle end_rod -9.0 44.5 912.0 0.5 1.6 0.5 0 2
particle end_rod -9.0 49 912.0 0.5 1.6 0.5 0 2

#level 35
particle end_rod -15 54 911 0.2 2 0.2 0 2
particle end_rod -15 49 911 0.2 2 0.2 0 2

#level 36
particle end_rod -43 53 911 0.2 2 0.2 0 4
particle portal -43.5 57.5 926.0 0 1 0.5 0.5 8

#level 39
particle end_rod -107 51 919 0.2 3 0.2 0 2
particle end_rod -99 56 911 0.2 2 0.2 0 2

#level 40
particle end_rod -120 49 911 0.2 2 0.2 0 2
particle end_rod -120 54 911 0.2 2 0.2 0 2

#level 42
particle end_rod -111.0 42 933.0 0.5 2 0.5 0 2
particle end_rod -111.0 49 933.0 0.5 2 0.5 0 2
particle end_rod -111.0 55 933.0 0.5 2 0.5 0 2

#level 50
particle end_rod 66 40 932 0.2 2 0.2 0 2
particle end_rod 66 44 932 0.2 2 0.2 0 2
particle end_rod 66 48 932 0.2 2 0.2 0 2
particle end_rod 66 52 932 0.2 2 0.2 0 2

#level 51
particle end_rod 53 20.5 954 0.2 2.2 0.2 0 2

#level 52
particle end_rod 39 34 969 0.2 1 0.2 0 2
particle end_rod 39 38 969 0.2 3.3 0.2 0 2
particle end_rod 39 43 969 0.2 3.3 0.2 0 2
particle end_rod 39 48 969 0.2 3.3 0.2 0 2
particle end_rod 39 52 969 0.2 3.3 0.2 0 2

#level 53
particle end_rod 26 49 970 0.25 2.5 0.25 0 2

#level 55
particle end_rod -30.00 13 969.00 0.5 2 0.5 0 2
particle end_rod -20.00 23 970.00 0.5 2.1 0.5 0 2
particle end_rod -16.00 36 955.00 0.5 2.1 0.5 0 2
particle end_rod -32 46 956 0.2 2.3 0.2 0 2

#level 60
particle end_rod -137 45 953 0.25 2 0.25 0 2
particle end_rod -137 50 953 0.25 1.8 0.25 0 2
particle end_rod -137 55 953 0.25 1.5 0.25 0 2

#level 65
particle minecraft:entity_effect{color:[0.2,0.8,1.0,1.0]} -44 2 983 1.000 1.000 1.000 1 0

#level 71
particle end_rod 52 50 1010 0.25 3.5 0.25 0 2

#level 76
particle end_rod -35.0 61 1013.0 0.5 0.8 0.5 0 2

#level 77
particle end_rod -58.0 43 997.0 0.5 2 0.5 0 2
particle end_rod -58.0 49 997.0 0.5 2 0.5 0 2

#level 78
particle end_rod -78 55 1008 0.25 2 0.25 0 2

#level 84
particle end_rod -73.0 19.0 1033.0 0.5 2.5 0.5 0 2
particle end_rod -73.0 27.0 1033.0 0.5 2.5 0.5 0 2

#level 90
particle end_rod 52.0 44.0 1026.0 0.5 2 0.5 0 2
particle end_rod 52.0 52.0 1026.0 0.5 2 0.5 0 2

#level 91
particle end_rod 59.0 45.5 1045.0 0.5 2 0.5 0 2
particle end_rod 59.0 52.5 1045.0 0.5 2 0.5 0 2
particle end_rod 59.0 48.5 1045.0 0.5 2 0.5 0 2

#level 97
particle end_rod -57 44 1054 0.25 2.5 0.25 0 2
particle end_rod -57 53 1054 0.25 2.5 0.25 0 2

#level 98
particle end_rod -78 49 1037 0.25 2.2 0.25 0 2

#end diamonds
particle end_rod -34 153 1130 2 3 2 0 2