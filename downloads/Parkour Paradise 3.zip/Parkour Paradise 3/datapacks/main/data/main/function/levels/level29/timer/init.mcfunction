tag @e[type=marker,name=console] add lvl29_timer2
scoreboard players set @e[type=marker,name=console] lvl29_timer2 0