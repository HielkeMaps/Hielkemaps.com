execute if score @s level matches 28 run function main:levels/level28/tick
execute if score @s level matches 32 run function main:levels/level32/tick
execute if score @s level matches 33 run function main:levels/level33/tick
execute if score @s level matches 34 run function main:levels/level34/tick
execute if score @s level matches 35 run function main:levels/level35/tick