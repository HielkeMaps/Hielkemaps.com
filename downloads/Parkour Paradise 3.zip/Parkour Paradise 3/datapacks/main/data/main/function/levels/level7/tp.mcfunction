tag @s add playsound_teleport
tp @s -12 60 849 270 10
execute at @s run particle minecraft:splash ~ ~1 ~ 0.2 0.5 0.2 0 100