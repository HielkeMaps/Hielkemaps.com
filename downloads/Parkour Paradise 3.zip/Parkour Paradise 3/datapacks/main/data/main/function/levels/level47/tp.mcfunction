tp @s 13 52 937 0 0
tag @s add playsound_teleport
effect give @s resistance 1 100 true