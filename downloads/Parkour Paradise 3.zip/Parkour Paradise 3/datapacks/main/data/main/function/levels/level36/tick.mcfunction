effect clear @s[x=-42,y=46,z=912,dx=-2,dy=14,dz=-2] levitation
effect give @s[x=-43,y=47,z=911,dx=0,dy=10,dz=0] levitation 1 5 true