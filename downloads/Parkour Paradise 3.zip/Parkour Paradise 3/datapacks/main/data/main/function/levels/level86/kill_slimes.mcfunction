tp @e[type=slime,tag=lvl86slime] ~ -1000 ~
kill @e[type=slime,tag=lvl86slime]