tag @s add playsound_teleport
tp @s -31 57 857 270 5