setblock -90 59 1013 minecraft:redstone_block

data merge block -91 59 1013 {Items:[{Slot:0b,id:"minecraft:minecart",Count:1b},{Slot:1b,id:"minecraft:minecart",Count:1b},{Slot:2b,id:"minecraft:minecart",Count:1b},{Slot:3b,id:"minecraft:minecart",Count:1b},{Slot:4b,id:"minecraft:minecart",Count:1b},{Slot:5b,id:"minecraft:minecart",Count:1b},{Slot:6b,id:"minecraft:minecart",Count:1b},{Slot:7b,id:"minecraft:minecart",Count:1b},{Slot:8b,id:"minecraft:minecart",Count:1b}]}


tag @s remove lvl78_ready