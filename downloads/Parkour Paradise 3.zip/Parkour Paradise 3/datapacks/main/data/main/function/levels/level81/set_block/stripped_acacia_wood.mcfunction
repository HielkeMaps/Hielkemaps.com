setblock ~ ~ ~ stripped_acacia_wood
playsound minecraft:block.piston.extend block @a ~ ~ ~