fill -100 36 959 -101 36 958 air
fill -100 35 958 -101 35 959 minecraft:sea_lantern
fill -100 34 958 -101 34 959 minecraft:blue_ice
function main:levels/level59/timer/on_level_change