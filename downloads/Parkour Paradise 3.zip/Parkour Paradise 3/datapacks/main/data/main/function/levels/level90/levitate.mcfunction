effect give @s levitation 3 10 true
playsound block.honey_block.slide master @a ~ ~ ~