fill -100 42 959 -101 42 958 air
fill -100 41 958 -101 41 959 minecraft:sea_lantern
fill -100 40 958 -101 40 959 minecraft:blue_ice
function main:levels/level59/timer/on_level_change