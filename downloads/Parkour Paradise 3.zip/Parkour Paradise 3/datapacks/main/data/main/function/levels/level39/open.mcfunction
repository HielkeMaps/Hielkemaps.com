setblock -100 55 914 iron_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
playsound block.iron_trapdoor.open block @a -100 55 914