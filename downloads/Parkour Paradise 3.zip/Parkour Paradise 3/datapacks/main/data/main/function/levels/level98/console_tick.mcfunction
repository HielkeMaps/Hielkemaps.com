scoreboard players add @s lvl98_timer 1

execute if score @s lvl98_timer matches 1 run setblock -85 57 1052 lily_pad
execute if score @s lvl98_timer matches 40 run setblock -85 57 1052 air

execute if score @s lvl98_timer matches 5 run setblock -89 55 1048 lily_pad
execute if score @s lvl98_timer matches 45 run setblock -89 55 1048 air

execute if score @s lvl98_timer matches 50 run setblock -87 55 1046 lily_pad
execute if score @s lvl98_timer matches 10 run setblock -87 55 1046 air

execute if score @s lvl98_timer matches 15 run setblock -88 54 1045 lily_pad
execute if score @s lvl98_timer matches 55 run setblock -88 54 1045 air

execute if score @s lvl98_timer matches 60 run setblock -85 57 1045 lily_pad
execute if score @s lvl98_timer matches 20 run setblock -85 57 1045 air

execute if score @s lvl98_timer matches 25 run setblock -83 56 1049 lily_pad
execute if score @s lvl98_timer matches 65 run setblock -83 56 1049 air

execute if score @s lvl98_timer matches 70 run setblock -79 55 1043 lily_pad
execute if score @s lvl98_timer matches 30 run setblock -79 55 1043 air

execute if score @s lvl98_timer matches 35 run setblock -80 55 1047 lily_pad
execute if score @s lvl98_timer matches 75 run setblock -80 55 1047 air

execute if score @s lvl98_timer matches 80 run setblock -87 56 1050 lily_pad
execute if score @s lvl98_timer matches 20 run setblock -87 56 1050 air

execute if score @s lvl98_timer matches 85 run setblock -82 56 1044 lily_pad
execute if score @s lvl98_timer matches 25 run setblock -82 56 1044 air

execute if score @s lvl98_timer matches 30 run setblock -89 57 1052 lily_pad
execute if score @s lvl98_timer matches 90 run setblock -89 57 1052 air

execute if score @s lvl98_timer matches 35 run setblock -84 54 1048 lily_pad
execute if score @s lvl98_timer matches 95 run setblock -84 54 1048 air

execute if score @s lvl98_timer matches 40 run setblock -83 60 1048 lily_pad
execute if score @s lvl98_timer matches 1 run setblock -83 60 1048 air

execute if score @s lvl98_timer matches 5 run setblock -79 58 1046 lily_pad
execute if score @s lvl98_timer matches 45 run setblock -79 58 1046 air

scoreboard players set @s[scores={lvl98_timer=100..}] lvl98_timer 0