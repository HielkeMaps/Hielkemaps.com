scoreboard players set @e[type=block_display,name=snake_80,tag=start,limit=1,scores={snake_80=-1}] snake_80 0
