effect clear @s[x=-17,y=28,z=869,dx=2,dy=8,dz=-2] levitation
effect give @s[x=-16,y=30,z=868,dx=0,dy=3,dz=0] levitation 1 5 true