effect clear @s[x=52,y=15,z=955,dx=0,dy=13,dz=-2] levitation
effect clear @s[x=53,y=15,z=953,dx=0,dy=13,dz=0] levitation
effect clear @s[x=54,y=28,z=953,dx=0,dy=-13,dz=2] levitation
effect clear @s[x=53,y=15,z=955,dx=0,dy=13,dz=0] levitation
effect clear @s[x=52,y=26,z=953,dx=2,dy=2,dz=2] levitation

effect give @s[x=53,y=15,z=954,dx=0,dy=10,dz=0,tag=isPlaying51] levitation 1 5 true