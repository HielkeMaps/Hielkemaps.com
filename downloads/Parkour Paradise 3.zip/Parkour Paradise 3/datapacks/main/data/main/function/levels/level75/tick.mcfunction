execute as @s[x=-28,y=23,z=999,dx=0,dy=1,dz=0] run function main:levels/level75/tp/1
execute as @s[x=-30,y=23,z=999,dx=0,dy=1,dz=0] run function main:levels/level75/tp/1
execute as @s[x=-32,y=23,z=999,dx=0,dy=1,dz=0] run function main:levels/level75/tp/1
execute as @s[x=-32,y=23,z=997,dx=0,dy=1,dz=0] run function main:levels/level75/tp/2
execute as @s[x=-32,y=23,z=995,dx=0,dy=1,dz=0] run function main:levels/level75/tp/1

execute as @s[x=-15,y=37,z=997,dx=0,dy=0,dz=0] run function main:levels/level75/tp/3