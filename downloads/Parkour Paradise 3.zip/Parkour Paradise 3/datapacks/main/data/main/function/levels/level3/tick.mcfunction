effect give @s[x=-78,y=55,z=865,dx=0,dy=1,dz=0] jump_boost 10 1
effect clear @s[x=-82,y=59,z=849,dx=-4,dy=2,dz=-2] jump_boost
effect clear @s[x=-93,y=61,z=866,dx=-4,dy=-4,dz=-4] jump_boost