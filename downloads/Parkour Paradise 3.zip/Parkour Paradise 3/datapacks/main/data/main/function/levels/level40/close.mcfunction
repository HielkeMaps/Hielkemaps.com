fill -136 33 926 -134 33 924 slime_block
scoreboard players reset @s lvl40_timer
tag @s remove lvl40_timer