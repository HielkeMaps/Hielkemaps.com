execute if score @s level matches 36 run function main:levels/level36/tick
execute if score @s level matches 37 run function main:levels/level37/tick
execute if score @s level matches 38 run function main:levels/level38/tick
execute if score @s level matches 39 run function main:levels/level39/player_tick
execute if score @s level matches 40 run function main:levels/level40/player_tick
execute if score @s level matches 42 run function main:levels/level42/tick