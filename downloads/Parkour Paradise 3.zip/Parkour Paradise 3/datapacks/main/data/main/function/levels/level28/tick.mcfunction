#level 28
effect clear @s[x=10,y=42,z=905,dx=2,dy=12,dz=-1] levitation
effect give @s[x=11,y=42,z=904,dx=0,dy=9,dz=0] levitation 1 6 true