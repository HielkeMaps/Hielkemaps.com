tag @s add playsound_teleport
tp @s -115 59 935 0 10
execute at @s run particle splash ~ ~1 ~ 0.2 0.5 0.2 0 100