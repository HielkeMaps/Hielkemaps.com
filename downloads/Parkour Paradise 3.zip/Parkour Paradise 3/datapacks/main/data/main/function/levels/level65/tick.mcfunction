tag @s[x=-44,y=2,z=983,dx=0,dy=0,dz=0] add lvl65_levitate
tag @s[x=-55,y=62,z=972,dx=4,dy=-5,dz=5] remove lvl65_levitate
tag @s[x=-47,y=52,z=986,dx=6,dy=5,dz=-6] remove lvl65_levitate

effect give @s[tag=lvl65_levitate,x=-41,y=1,z=986,dx=-6,dy=7,dz=-6] levitation 2 2
effect give @s[tag=lvl65_levitate,x=-41,y=8,z=986,dx=-6,dy=43,dz=-6] levitation 2 7