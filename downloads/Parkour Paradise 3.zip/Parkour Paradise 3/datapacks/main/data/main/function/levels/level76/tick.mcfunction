effect give @s[x=-36,y=60,z=1012,dx=1,dy=1,dz=1] slow_falling 5 1 false
effect clear @s[scores={level=77}] slow_falling