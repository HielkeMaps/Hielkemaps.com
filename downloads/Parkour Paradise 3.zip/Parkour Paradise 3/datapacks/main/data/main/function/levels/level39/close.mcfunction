setblock -100 55 914 iron_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
playsound block.iron_trapdoor.close block @a -100 55 914