effect give @s[x=-9,y=43,z=911,dx=-1,dy=10,dz=1] levitation 1 8 true
effect clear @s[x=-8,y=43,z=911,dx=0,dy=11,dz=1] levitation
effect give @s[x=-7,y=47,z=924,dx=0,dy=6,dz=0] slow_falling 1 1 true