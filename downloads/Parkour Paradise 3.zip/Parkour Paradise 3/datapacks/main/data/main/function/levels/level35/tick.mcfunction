effect clear @s[x=-16,y=44,z=911,dx=2,dy=20,dz=0] levitation
effect give @s[x=-15,y=45,z=911,dx=0,dy=14,dz=0] levitation 1 8 true