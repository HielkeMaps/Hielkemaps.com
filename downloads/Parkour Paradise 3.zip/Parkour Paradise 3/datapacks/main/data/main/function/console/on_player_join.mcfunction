scoreboard players reset * level_display
function main:horse/kill/check