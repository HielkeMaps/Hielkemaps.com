fill -100 35 959 -101 35 958 air
fill -100 34 958 -101 34 959 minecraft:sea_lantern
function main:levels/level59/timer/on_level_change