execute if block 38 35 897 lever[powered=true] run setblock 45 37 890 stone
execute if block 38 35 897 lever[powered=false] run setblock 45 37 890 redstone_block

execute if block 38 35 897 lever[powered=true] run scoreboard players add @s lvl29_timer2 1
execute if block 38 35 897 lever[powered=false] run scoreboard players set @s lvl29_timer2 -33

execute as @s[scores={lvl29_timer2=-32}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=-15}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=1}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=14}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=27}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=39}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=50}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=60}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=69}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=77}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=84}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=90}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=95}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=99}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=102}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=104}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=106}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=108}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=110}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=111}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=112}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=113}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=114}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=115}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=116}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=117}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=118}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=119}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=120}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=121}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=122}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=123}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=124}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896
execute as @s[scores={lvl29_timer2=125}] run playsound block.note_block.hat master @a[scores={level=29}] 38 35 896

execute as @s[scores={lvl29_timer2=125}] run setblock 38 35 897 lever[face=wall,facing=south,powered=false]