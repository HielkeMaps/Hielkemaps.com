tag @e[type=marker,name=console] add lvl31_timer
scoreboard players set @e[type=marker,name=console,scores={lvl31_timer=11..}] lvl31_timer 10