tp @s 67 20 982 40 20
tag @s add playsound_teleport