execute as @e[type=block_display,name=snake_15] unless score @s snake_15 matches -1 at @s run function main:snake/15/tick
execute as @e[type=block_display,name=snake_15,scores={snake_15=1}] at @s run scoreboard players set @e[type=block_display,name=snake_15,distance=0.1..1.1,scores={snake_15=-1}] snake_15 0
execute as @e[type=block_display,name=snake_42] unless score @s snake_42 matches -1 at @s run function main:snake/42/tick
execute as @e[type=block_display,name=snake_42,scores={snake_42=1}] at @s run scoreboard players set @e[type=block_display,name=snake_42,distance=0.1..1.1,scores={snake_42=-1}] snake_42 0
execute as @e[type=block_display,name=snake_73] unless score @s snake_73 matches -1 at @s run function main:snake/73/tick
execute as @e[type=block_display,name=snake_73,scores={snake_73=1}] at @s run scoreboard players set @e[type=block_display,name=snake_73,distance=0.1..1.1,scores={snake_73=-1}] snake_73 0
execute as @e[type=block_display,name=snake_80] unless score @s snake_80 matches -1 at @s run function main:snake/80/tick
execute as @e[type=block_display,name=snake_80,scores={snake_80=1}] at @s run scoreboard players set @e[type=block_display,name=snake_80,distance=0.1..1.1,scores={snake_80=-1}] snake_80 0
execute as @e[type=block_display,name=snake_91] unless score @s snake_91 matches -1 at @s run function main:snake/91/tick
execute as @e[type=block_display,name=snake_91,scores={snake_91=1}] at @s run scoreboard players set @e[type=block_display,name=snake_91,distance=0.1..1.1,scores={snake_91=-1}] snake_91 0
execute as @e[type=block_display,name=snake_99] unless score @s snake_99 matches -1 at @s run function main:snake/99/tick
execute as @e[type=block_display,name=snake_99,scores={snake_99=1}] at @s run scoreboard players set @e[type=block_display,name=snake_99,distance=0.1..1.1,scores={snake_99=-1}] snake_99 0
