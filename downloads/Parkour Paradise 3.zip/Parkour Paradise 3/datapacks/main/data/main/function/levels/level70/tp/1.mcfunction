tp @s 51 18 980 320 0
tag @s add playsound_teleport