effect clear @s[x=65,y=37,z=933,dx=2,dy=22,dz=-2] levitation
effect give @s[x=66,y=37,z=932,dx=0,dy=19,dz=0] levitation 1 10 true