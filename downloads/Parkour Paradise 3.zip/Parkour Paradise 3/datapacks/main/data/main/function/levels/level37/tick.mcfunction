attribute @s[x=-56,y=0,z=929,dx=-19,dy=29,dz=-19] minecraft:gravity modifier add lvl37 -2 add_multiplied_total
attribute @s[x=-56,y=30,z=910,dx=-19,dy=20,dz=19] minecraft:gravity modifier remove lvl37


#/summon block_display -62 40 917 {Rotation:[180F,0F],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[90f,0f,90f,1f],translation:[-0.5f,1f,-0.5f],scale:[1f,1f,1f]},block_state:{Name:"minecraft:chest",Properties:{facing:"north"}}}


#/summon block_display -68 40 926 {transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[90f,0f,90f,1f],translation:[-0.5f,1f,-0.5f],scale:[1f,1f,1f]},block_state:{Name:"minecraft:dead_bush"}}