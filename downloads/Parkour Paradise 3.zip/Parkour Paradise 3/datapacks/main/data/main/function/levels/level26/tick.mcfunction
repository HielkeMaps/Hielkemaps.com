effect clear @s[x=-32,y=36,z=907,dx=1,dy=30,dz=-2] levitation
effect give @s[x=-31,y=36,z=906,dx=0,dy=17,dz=0] levitation 1 5 true