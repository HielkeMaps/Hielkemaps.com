effect clear @s[x=-126,y=44,z=862,dx=-2,dy=14,dz=2] levitation
effect give @s[x=-127,y=45,z=863,dx=0,dy=11,dz=0] levitation 1 8 true