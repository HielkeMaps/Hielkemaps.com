execute if score @s level matches 71 run function main:levels/level71/tick
execute if score @s level matches 73 run function main:levels/level73/tick
execute if score @s level matches 75 run function main:levels/level75/tick
execute if score @s level matches 76 run function main:levels/level76/tick
execute if score @s level matches 77 run function main:levels/level77/tick
execute if score @s level matches 78 run function main:levels/level78/player_tick