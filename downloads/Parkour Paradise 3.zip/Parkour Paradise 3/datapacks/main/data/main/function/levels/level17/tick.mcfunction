effect give @s[x=-57,y=36,z=869,dx=0,dy=22,dz=0] levitation 1 8 true
effect clear @s[x=-57,y=36,z=870,dx=0,dy=1,dz=0] levitation
effect clear @s[x=-58,y=60,z=870,dx=2,dy=3,dz=-2] levitation