effect clear @s[x=-60,y=40,z=998,dx=3,dy=11,dz=1] levitation
effect clear @s[x=-57,y=41,z=997,dx=0,dy=10,dz=-2] levitation
effect clear @s[x=-58,y=51,z=995,dx=-2,dy=-10,dz=0] levitation
effect clear @s[x=-60,y=41,z=996,dx=0,dy=10,dz=1] levitation
effect clear @s[x=-60,y=54,z=995,dx=3,dy=3,dz=3] levitation

effect give @s[x=-59,y=40,z=997,dx=1,dy=13,dz=-1] levitation 5 1 true

effect clear @s slow_falling