tag @s add playsound_teleport
tp @s -77 42 924 55 0