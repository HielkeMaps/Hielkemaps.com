effect clear @s[x=-22,y=61,z=866,dx=3,dy=-53,dz=-2] levitation
effect give @s[x=-20,y=9,z=865,dx=-1,dy=49,dz=0] levitation 1 15 true