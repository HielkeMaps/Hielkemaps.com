execute if score @s level matches ..35 run function main:player/level_tree/1/2/1/tick
execute if score @s level matches 36.. run function main:player/level_tree/1/2/2/tick