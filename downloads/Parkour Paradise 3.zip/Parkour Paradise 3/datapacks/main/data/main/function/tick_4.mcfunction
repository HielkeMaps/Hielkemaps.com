schedule function main:tick_4 4t

#snake
function main:snake/tick_4