execute if score @s level matches 1 run function main:levels/level1/tick
execute if score @s level matches 2 run function main:levels/level2/tick
execute if score @s level matches 3 run function main:levels/level3/tick
execute if score @s level matches 6 run function main:levels/level6/tick
execute if score @s level matches 7 run function main:levels/level7/tick