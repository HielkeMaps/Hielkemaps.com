execute if score @s level matches ..78 run function main:player/level_tree/2/2/1/tick
execute if score @s level matches 84.. run function main:player/level_tree/2/2/2/tick