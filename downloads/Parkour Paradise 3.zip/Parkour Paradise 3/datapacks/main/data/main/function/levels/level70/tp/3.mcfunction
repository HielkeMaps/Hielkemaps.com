tp @s 69 21 990 60 0
tag @s add playsound_teleport