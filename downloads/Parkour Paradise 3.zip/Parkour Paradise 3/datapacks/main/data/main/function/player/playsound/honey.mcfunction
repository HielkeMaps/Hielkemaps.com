playsound block.honey_block.slide master @s
tag @s remove playsound_honey