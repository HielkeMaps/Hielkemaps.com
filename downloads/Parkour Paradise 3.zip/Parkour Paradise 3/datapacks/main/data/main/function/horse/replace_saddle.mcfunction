data merge entity @s {Silent:1b}
data merge entity @s {equipment:{saddle:{count:1,id:"minecraft:saddle"}}}
data merge entity @s {Silent:0b}
clear @a minecraft:saddle