effect clear @s[x=-106,y=46,z=918,dx=-2,dy=15,dz=2] levitation
effect give @s[x=-107,y=46,z=919,dx=0,dy=13,dz=0] levitation 1 8 true
effect clear @s[x=-100,y=51,z=912,dx=1,dy=11,dz=-1] levitation
effect give @s[x=-99,y=52,z=911,dx=0,dy=9,dz=0] levitation 1 8 true