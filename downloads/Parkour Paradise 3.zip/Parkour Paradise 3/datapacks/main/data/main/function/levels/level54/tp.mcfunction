tp @s 6 55 970 140 0
tag @s add playsound_teleport