effect clear @s[x=60,y=43,z=1046,dx=-3,dy=3,dz=-3] levitation
effect give @s[x=59,y=42,z=1044,dx=-1,dy=16,dz=1] levitation 1 5 true
effect clear @s[x=57,y=59,z=1043,dx=3,dy=5,dz=3] levitation