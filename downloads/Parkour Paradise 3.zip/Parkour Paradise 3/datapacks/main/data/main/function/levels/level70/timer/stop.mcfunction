setblock 53 51 984 end_stone
tag @s remove lvl70_timer
scoreboard players set @s lvl70_timer 0