execute if score @s level matches ..70 run function main:player/level_tree/2/1/tick
execute if score @s level matches 71.. run function main:player/level_tree/2/2/tick