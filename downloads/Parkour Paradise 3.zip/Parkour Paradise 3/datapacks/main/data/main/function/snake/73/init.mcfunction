scoreboard players set @e[type=block_display,name=snake_73,tag=start,limit=1,scores={snake_73=-1}] snake_73 0
