tag @s add playsound_teleport
tp @s 56 37 861 125 10