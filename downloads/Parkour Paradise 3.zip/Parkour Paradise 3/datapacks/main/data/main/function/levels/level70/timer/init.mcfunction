tag @e[type=marker,name=console] add lvl70_timer
scoreboard players set @e[type=marker,name=console] lvl70_timer 0