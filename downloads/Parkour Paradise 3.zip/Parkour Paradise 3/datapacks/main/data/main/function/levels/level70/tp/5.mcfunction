tp @s 65 53 990 180 0
tag @s add playsound_teleport