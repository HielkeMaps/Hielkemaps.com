tag @s remove lvl59_up
execute if entity @a[x=-101,y=35,z=959,dx=1,dy=10,dz=-1] run tag @s add lvl59_up

function main:levels/level59/timer/tick