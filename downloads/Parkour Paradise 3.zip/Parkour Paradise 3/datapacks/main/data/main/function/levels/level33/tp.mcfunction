effect give @s resistance 1 10 true
tp @s 28.0 58 922.0 180 20
tag @s add playsound_teleport