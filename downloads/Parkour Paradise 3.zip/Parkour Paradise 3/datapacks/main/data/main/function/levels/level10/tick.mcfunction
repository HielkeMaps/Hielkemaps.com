execute as @s[x=62,y=27,z=864,dx=0,dy=1,dz=0] run function main:levels/level10/tp
execute as @s[x=57,y=37,z=862,dx=0,dy=1,dz=0] run function main:levels/level10/tp2

effect clear @s[x=70,y=52,z=847,dx=-3,dy=-20,dz=3] levitation
effect give @s[x=68,y=33,z=849,dx=1,dy=14,dz=-1] levitation 1 10 true