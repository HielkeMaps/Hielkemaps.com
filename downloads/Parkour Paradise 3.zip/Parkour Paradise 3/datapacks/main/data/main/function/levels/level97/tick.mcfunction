effect give @s[x=-57,y=58,z=1054,dx=0,dy=-19,dz=0] levitation 1 8 true
effect clear @s[x=-56,y=60,z=1055,dx=-2,dy=2,dz=-2] levitation
effect clear @s[x=-57,y=39,z=1053,dx=0,dy=3,dz=0] levitation