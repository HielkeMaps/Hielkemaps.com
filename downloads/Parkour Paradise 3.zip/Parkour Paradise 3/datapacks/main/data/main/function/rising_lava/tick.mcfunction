#level 32
execute if entity @a[scores={level=32}] as @e[type=armor_stand,name=lvl32rising,limit=1] run function main:rising_lava/32/tick

#level 51
execute if entity @a[scores={level=51}] as @e[type=armor_stand,name=lvl51rising,limit=1] run function main:rising_lava/51/tick

#level 77
execute if entity @a[scores={level=77}] as @e[type=armor_stand,name=lvl77rising,limit=1] run function main:rising_lava/77/tick