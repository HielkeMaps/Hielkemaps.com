execute if score @s level matches ..7 run function main:player/level_tree/1/1/1/tick
execute if score @s level matches 10.. run function main:player/level_tree/1/1/2/tick