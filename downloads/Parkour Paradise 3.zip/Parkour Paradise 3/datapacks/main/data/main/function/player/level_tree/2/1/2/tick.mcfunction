execute if score @s level matches 54 run function main:levels/level54/tick
execute if score @s level matches 55 run function main:levels/level55/tick
execute if score @s level matches 60 run function main:levels/level60/tick
execute if score @s level matches 62 run function main:levels/level62/player_tick
execute if score @s level matches 65 run function main:levels/level65/tick
execute if score @s level matches 70 run function main:levels/level70/player_tick