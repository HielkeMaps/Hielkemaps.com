effect clear @s[scores={level=16}] levitation

execute at @s if block ~ ~1 ~ honey_block run function main:levels/level16/levitate
execute at @s if block ~ ~2 ~ honey_block run function main:levels/level16/levitate
execute at @s if block ~ ~2.7 ~ honey_block run function main:levels/level16/levitate