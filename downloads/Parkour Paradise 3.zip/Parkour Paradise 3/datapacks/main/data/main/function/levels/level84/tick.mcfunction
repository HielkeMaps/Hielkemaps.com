effect clear @s[x=-72,y=16,z=1031,dx=-2,dy=11,dz=0] levitation
effect clear @s[x=-75,y=16,z=1031,dx=0,dy=9,dz=3] levitation
effect clear @s[x=-75,y=16,z=1034,dx=3,dy=9,dz=0] levitation
effect clear @s[x=-72,y=16,z=1034,dx=0,dy=10,dz=-3] levitation
effect clear @s[x=-74,y=30,z=1034,dx=3,dy=3,dz=-3] levitation

effect give @s[x=-73,y=16,z=1032,dx=-1,dy=16,dz=1] levitation 1 5 true