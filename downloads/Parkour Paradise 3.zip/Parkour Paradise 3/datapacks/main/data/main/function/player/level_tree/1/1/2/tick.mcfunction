execute if score @s level matches 10 run function main:levels/level10/tick
execute if score @s level matches 15 run function main:levels/level15/player_tick
execute if score @s level matches 16 run function main:levels/level16/tick
execute if score @s level matches 17 run function main:levels/level17/tick
execute if score @s level matches 26 run function main:levels/level26/tick