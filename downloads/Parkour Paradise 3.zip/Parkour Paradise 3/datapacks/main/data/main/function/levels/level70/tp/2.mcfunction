tp @s 68 15 982 25 0
tag @s add playsound_teleport