tp @s -31.0 33 1004.0 180 0
tag @s add playsound_teleport