execute if score @s level matches 84 run function main:levels/level84/tick
execute if score @s level matches 89 run function main:levels/level89/player_tick
execute if score @s level matches 90 run function main:levels/level90/tick
execute if score @s level matches 91 run function main:levels/level91/tick
execute if score @s level matches 97 run function main:levels/level97/tick
execute if score @s level matches 98 run function main:levels/level98/player_tick