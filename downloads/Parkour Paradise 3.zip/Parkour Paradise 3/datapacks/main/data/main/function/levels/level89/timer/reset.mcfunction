clone 32 45 1023 32 45 1023 32 45 1020
scoreboard players reset @s lvl89_timer
scoreboard players set @s lvl89_count 0

tp @e[type=slime,tag=lvl89slime] ~ -200 ~