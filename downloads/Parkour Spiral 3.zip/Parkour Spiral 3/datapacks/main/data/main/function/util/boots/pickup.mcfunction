item replace entity @s armor.feet with netherite_boots[tooltip_display={hidden_components:[enchantments]},unbreakable={},custom_data={"hielkemaps:item":true},enchantments={"minecraft:frost_walker":1,"minecraft:binding_curse":1,"minecraft:vanishing_curse":1}]
playsound item.armor.equip_netherite master @s ~ ~ ~ 1 1 1
advancement grant @s only main:lava_walker
tag @s add fire_boots