# Generated from main on_join, without the lines that reset progress
attribute @s minecraft:burning_time base set 0.001
tp @s 0 -60 -25 0 10
spawnpoint @s 0 -60 -25
gamemode adventure @s
tag @s remove ingame
function time:reset
tag @s remove water_damage
tag @s remove dripstone_fall
clear @s *[minecraft:custom_data~{"hielkemaps:item":true}]
execute as @s[tag=training_mode] run function trainingmode:leave
