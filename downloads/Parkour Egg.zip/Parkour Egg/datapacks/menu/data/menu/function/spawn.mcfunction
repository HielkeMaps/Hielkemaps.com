# Generated from main on_join, without the lines that reset progress
attribute @s minecraft:burning_time base set 0.001
tp @s 0 10 -30 0 5
spawnpoint @s 0 10 -30
gamemode adventure @s
clear @s *[minecraft:custom_data~{"hielkemaps:item":true}]
execute as @s[tag=training_mode] run function trainingmode:leave
function time:reset
