spawnpoint @s 0 10 -30

clear @s *[minecraft:custom_data~{"hielkemaps:item":true},!minecraft:custom_data~{"tm:item":true}]
effect clear @s


function time:reset

tag @s remove finished

tag @s remove timer_intro
scoreboard players reset @s timer_intro

tag @s remove ingame
tag @s remove water_damage
tag @s add spawn

title @s title ""