summon minecraft:tnt -12 115 104 {fuse:80}
summon minecraft:tnt -11 115 103 {fuse:80}
summon minecraft:tnt -12 115 102 {fuse:80}
summon minecraft:tnt -13 115 103 {fuse:80}

summon minecraft:tnt -12 115 104 {fuse:80}
summon minecraft:tnt -11 115 103 {fuse:80}
summon minecraft:tnt -12 115 102 {fuse:80}
summon minecraft:tnt -13 115 103 {fuse:80}

playsound minecraft:entity.tnt.primed block @a -12 116 103
playsound minecraft:entity.tnt.primed block @a -12 116 103
playsound minecraft:entity.tnt.primed block @a -12 116 103
playsound minecraft:entity.tnt.primed block @a -12 116 103