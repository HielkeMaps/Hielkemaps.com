tp @s 0 10 -18 0 5
gamemode adventure @s

function time:reset
clear @s *[minecraft:custom_data~{"hielkemaps:item":true},!minecraft:custom_data~{"tm:item":true}]