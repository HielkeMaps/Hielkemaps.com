#summon with passenger otherwise you can get in
summon minecart ~ ~ ~ {Tags:["tnt_minecart"],Invulnerable:1b,CustomDisplayTile:1b,DisplayOffset:6,Passengers:[{id:"minecraft:marker",CustomName:"minecart_marker"}],DisplayState:{Name:"minecraft:tnt",Properties:{unstable:"false"}}}
playsound minecraft:block.dispenser.dispense block @a