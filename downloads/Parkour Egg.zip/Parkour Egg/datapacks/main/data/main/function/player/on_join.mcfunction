attribute @s minecraft:burning_time base set 0.001

tp @s 0 10 -30 0 5
spawnpoint @s 0 10 -30
gamemode adventure @s
tag @s add joined

clear @s *[minecraft:custom_data~{"hielkemaps:item":true}]
execute as @s[tag=training_mode] run function trainingmode:leave

function time:reset

advancement revoke @s from main:start
advancement revoke @s from main:easter_eggs/root
scoreboard players set @s eefound 0