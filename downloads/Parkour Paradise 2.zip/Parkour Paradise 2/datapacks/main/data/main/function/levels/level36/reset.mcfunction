setblock 99928 26 99950 air

tag @e[type=marker,name=console] remove lvl36timer
scoreboard players reset @e[type=marker,name=console] lvl36timer