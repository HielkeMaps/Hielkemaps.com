tag @e[type=marker,name=console] add lvl36timer
scoreboard players set @e[type=marker,name=console] lvl36timer 0