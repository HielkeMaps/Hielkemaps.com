tag @a[x=99846,y=29,z=99845,dx=2,dy=2,dz=-3] add tped
execute as @a[tag=tped] at @s run tp @s ~-12 ~202 ~-2
execute as @a[tag=tped,gamemode=!spectator] run attribute @s minecraft:gravity modifier add space -0.75 add_multiplied_base
playsound minecraft:block.iron_door.open master @a[tag=tped] 99835 231 99843

tag @s remove fire
scoreboard players reset @s lvl91timer

#open door
setblock 99847 29 99845 minecraft:iron_door[facing=east,half=lower,hinge=right,open=false]
setblock 99847 30 99845 minecraft:iron_door[facing=east,half=upper,hinge=right,open=false]
playsound minecraft:block.iron_door.open block @a 99847 29 99845

tag @a[tag=tped] remove tped