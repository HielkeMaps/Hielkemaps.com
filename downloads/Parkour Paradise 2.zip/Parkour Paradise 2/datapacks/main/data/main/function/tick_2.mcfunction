schedule function main:tick_2 2t replace

#spawn
execute as @a[x=99918,y=105,z=100088,dx=2,dy=2,dz=0] run function main:tp/to_start

execute as @a[tag=playsound_teleport] at @s run playsound minecraft:entity.enderman.teleport master @s
tag @a remove playsound_teleport

#nether tp
execute as @a[tag=netherin,nbt={Dimension:"minecraft:the_nether"}] at @s run tp @s 12489 53 12491 25 10
tag @a[nbt={Dimension:"minecraft:the_nether"}] remove netherin

execute as @a[gamemode=!spectator,tag=!inspace] run function main:setlevel

#On join
execute as @a[tag=!joined] run function main:on_join

#end
function main:end/tick

execute as @a[tag=ontower,gamemode=!spectator] at @s if block ~ ~ ~ water run function main:tp/to_tower
effect give @a[tag=ontower] night_vision infinite 1 true
tag @a[tag=end] remove ontower
effect clear @a[tag=end] night_vision

function main:util/elytra/tick

#reset trigger
scoreboard players enable @a reset
scoreboard players set @a[tag=inRace] reset 0
tag @a[scores={reset=1}] remove joined
scoreboard players set @a reset 0

#restart trigger
scoreboard players enable @a restart
scoreboard players set @a[tag=inRace] restart 0
execute as @a[scores={restart=1}] run function main:restart
scoreboard players set @a restart 0