tag @s remove inspace
attribute @s[gamemode=!spectator] minecraft:gravity modifier remove space

tp @s 99858 21 99847 270 10
tag @s add playsound_teleport