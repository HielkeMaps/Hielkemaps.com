tag @s remove end
tag @s remove ontower
tag @s remove inspace
effect clear @s
clear @s *[minecraft:custom_data~{"hielkemaps:item":true},!minecraft:custom_data~{"tm:item":true}]

tp @s 99991 130 99991 135 50
tag @s add playsound_teleport

effect give @s[gamemode=!spectator] slow_falling infinite 10 true
execute as @s[tag=!inRace,gamemode=!spectator] run function time:start
tag @s[gamemode=!spectator] add title_start