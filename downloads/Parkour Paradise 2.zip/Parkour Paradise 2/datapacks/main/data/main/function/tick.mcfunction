function main:levels/tick

execute as @a[tag=title_start] at @s run function main:title/start