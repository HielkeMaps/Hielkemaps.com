schedule function main:tick_10 10t

spawnpoint @a 99919 106 100110 180 0
effect give @a resistance infinite 10 true
effect give @a saturation infinite 10 true

#kill items
execute as @e[type=item] unless items entity @s contents *[minecraft:custom_data~{"hielkemaps:stay":true}] run kill