#end detection
execute as @a[tag=ingame,x=100083,y=75,z=100088,distance=..20,gamemode=!spectator] run function time:finish

#end tag
tag @a[x=100087,y=70,z=100117,dx=8,dy=10,dz=-8,gamemode=!spectator] add end
execute as @a[tag=end,gamemode=!spectator] at @s if block ~ ~ ~ water run function main:tp/to_end

#particles and levitation
execute as @a[x=100087,y=16,z=100117,dx=8,dy=50,dz=-8,gamemode=!spectator] at @s if block ~ 16 ~ diamond_block run clear @s
execute as @a[x=100087,y=16,z=100117,dx=8,dy=50,dz=-8,gamemode=!spectator] at @s if block ~ 16 ~ diamond_block run effect give @s levitation 1 10 true
particle minecraft:end_rod 100091 20 100113 2 5 2 0 6 force
particle minecraft:end_rod 100091 30 100113 2 5 2 0 6 force
particle minecraft:end_rod 100091 40 100113 2 5 2 0 6 force
particle minecraft:end_rod 100091 50 100113 2 5 2 0 6 force
particle minecraft:end_rod 100091 60 100113 2 5 2 0 6 force

#back to spawn portal
execute as @a[x=100066,y=73,z=100089,dx=0,dy=2,dz=-2] run function main:tp/to_spawn