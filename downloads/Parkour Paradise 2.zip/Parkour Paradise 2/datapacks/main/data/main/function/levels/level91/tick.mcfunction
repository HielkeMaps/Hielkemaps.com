execute as @e[type=marker,name=console,tag=fire] run function main:levels/level91/fire

tag @a[x=99791,y=200,z=99855,dx=97,dy=51,dz=-86,gamemode=!spectator] add inspace

#portal back
execute as @a[x=99880,y=219,z=99817,dx=-2,dy=2,dz=0] run function main:levels/level91/tpback

#keep in space
execute as @a[tag=inspace] unless entity @s[x=99750,y=200,z=99890,dx=160,dy=100,dz=-160] run tp @s 99835 231 99842