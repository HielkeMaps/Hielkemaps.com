attribute @s minecraft:burning_time base set 0.001

tp @s 99919 106 100110 180 5
gamemode adventure @s
tag @s remove ingame
function time:reset
scoreboard players reset @s level
scoreboard players reset @s level_display

tag @s remove end
tag @s remove ontower
tag @s remove inspace
attribute @s minecraft:gravity modifier remove space
effect clear @s

clear @s *[minecraft:custom_data~{"hielkemaps:item":true}]
execute as @s[tag=training_mode] run function trainingmode:leave

tag @s add joined