tp @s 99919 105 100092 180 0
gamemode adventure @s
tag @s remove ingame
scoreboard players reset @s level
scoreboard players reset @s level_display

function time:reset

tag @s remove end
tag @s remove ontower
tag @s remove inspace
attribute @s minecraft:gravity modifier remove space
effect clear @s
clear @s *[minecraft:custom_data~{"hielkemaps:item":true},!minecraft:custom_data~{"tm:item":true}]