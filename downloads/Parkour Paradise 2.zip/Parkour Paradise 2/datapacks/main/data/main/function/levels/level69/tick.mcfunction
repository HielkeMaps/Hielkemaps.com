execute if entity @a[scores={level=68..70}] run scoreboard players add @s lvl69timer 1

#cannon 1
execute if score @s lvl69timer matches 1 run setblock 99865 24 99896 coal_block
execute if score @s lvl69timer matches 1 run particle minecraft:explosion 99865.9 24.5 99896 0 0 0 0.05 1 normal
execute if score @s lvl69timer matches 1 run playsound minecraft:entity.generic.explode master @a[scores={level=68..70}] 99866 24 99896 0.5 0.7

execute if score @s lvl69timer matches 15 run setblock 99865 24 99896 air
execute if score @s lvl69timer matches 15 run setblock 99864 24 99896 coal_block
execute if score @s lvl69timer matches 15 run setblock 99865 24 99896 fire[west=true]

execute if score @s lvl69timer matches 30 run setblock 99865 24 99896 air
execute if score @s lvl69timer matches 30 run setblock 99864 24 99896 air
execute if score @s lvl69timer matches 30 run setblock 99863 24 99896 coal_block
execute if score @s lvl69timer matches 30 run setblock 99864 24 99896 fire[west=true]

execute if score @s lvl69timer matches 45 run setblock 99864 24 99896 air
execute if score @s lvl69timer matches 45 run setblock 99863 24 99896 air
execute if score @s lvl69timer matches 45 run setblock 99862 24 99896 coal_block
execute if score @s lvl69timer matches 45 run setblock 99863 24 99896 fire[west=true]

execute if score @s lvl69timer matches 60 run setblock 99863 24 99896 air
execute if score @s lvl69timer matches 60 run setblock 99862 24 99896 air
execute if score @s lvl69timer matches 60 run setblock 99861 24 99896 coal_block
execute if score @s lvl69timer matches 60 run setblock 99862 24 99896 fire[west=true]

execute if score @s lvl69timer matches 75 run setblock 99862 24 99896 air
execute if score @s lvl69timer matches 75 run setblock 99861 24 99896 air
execute if score @s lvl69timer matches 75 run setblock 99860 24 99896 coal_block
execute if score @s lvl69timer matches 75 run setblock 99861 24 99896 fire[west=true]

execute if score @s lvl69timer matches 90 run setblock 99861 24 99896 air
execute if score @s lvl69timer matches 90 run setblock 99860 24 99896 air
execute if score @s lvl69timer matches 90 run setblock 99859 24 99896 coal_block
execute if score @s lvl69timer matches 90 run setblock 99860 24 99896 fire[west=true]

execute if score @s lvl69timer matches 105 run setblock 99860 24 99896 air
execute if score @s lvl69timer matches 105 run setblock 99859 24 99896 air
execute if score @s lvl69timer matches 105 run setblock 99858 24 99896 coal_block
execute if score @s lvl69timer matches 105 run setblock 99859 24 99896 fire[west=true]

execute if score @s lvl69timer matches 120 run setblock 99859 24 99896 air
execute if score @s lvl69timer matches 120 run setblock 99858 24 99896 air
execute if score @s lvl69timer matches 120 run setblock 99857 24 99896 coal_block
execute if score @s lvl69timer matches 120 run setblock 99858 24 99896 fire[west=true]

execute if score @s lvl69timer matches 15 run setblock 99858 24 99896 air
execute if score @s lvl69timer matches 15 run setblock 99857 24 99896 air
execute if score @s lvl69timer matches 15 run setblock 99856 24 99896 coal_block
execute if score @s lvl69timer matches 15 run setblock 99857 24 99896 fire[west=true]

execute if score @s lvl69timer matches 30 run setblock 99857 24 99896 air
execute if score @s lvl69timer matches 30 run setblock 99856 24 99896 air

#cannon 2
execute if score @s lvl69timer matches 35 run setblock 99864 24 99893 coal_block
execute if score @s lvl69timer matches 35 run particle minecraft:explosion 99864.9 24.5 99893 0 0 0 0.05 1 normal
execute if score @s lvl69timer matches 35 run playsound minecraft:entity.generic.explode master @a[scores={level=68..70}] 99865 24 99893 0.5 0.7

execute if score @s lvl69timer matches 50 run setblock 99864 24 99893 air
execute if score @s lvl69timer matches 50 run setblock 99863 24 99893 coal_block
execute if score @s lvl69timer matches 50 run setblock 99864 24 99893 fire[west=true]

execute if score @s lvl69timer matches 65 run setblock 99864 24 99893 air
execute if score @s lvl69timer matches 65 run setblock 99863 24 99893 air
execute if score @s lvl69timer matches 65 run setblock 99862 24 99893 coal_block
execute if score @s lvl69timer matches 65 run setblock 99863 24 99893 fire[west=true]

execute if score @s lvl69timer matches 80 run setblock 99863 24 99893 air
execute if score @s lvl69timer matches 80 run setblock 99862 24 99893 air
execute if score @s lvl69timer matches 80 run setblock 99861 24 99893 coal_block
execute if score @s lvl69timer matches 80 run setblock 99862 24 99893 fire[west=true]

execute if score @s lvl69timer matches 95 run setblock 99862 24 99893 air
execute if score @s lvl69timer matches 95 run setblock 99861 24 99893 air
execute if score @s lvl69timer matches 95 run setblock 99860 24 99893 coal_block
execute if score @s lvl69timer matches 95 run setblock 99861 24 99893 fire[west=true]

execute if score @s lvl69timer matches 110 run setblock 99861 24 99893 air
execute if score @s lvl69timer matches 110 run setblock 99860 24 99893 air
execute if score @s lvl69timer matches 110 run setblock 99859 24 99893 coal_block
execute if score @s lvl69timer matches 110 run setblock 99860 24 99893 fire[west=true]

execute if score @s lvl69timer matches 5 run setblock 99860 24 99893 air
execute if score @s lvl69timer matches 5 run setblock 99859 24 99893 air
execute if score @s lvl69timer matches 5 run setblock 99858 24 99893 coal_block
execute if score @s lvl69timer matches 5 run setblock 99859 24 99893 fire[west=true]

execute if score @s lvl69timer matches 20 run setblock 99859 24 99893 air
execute if score @s lvl69timer matches 20 run setblock 99858 24 99893 air
execute if score @s lvl69timer matches 20 run setblock 99857 24 99893 coal_block
execute if score @s lvl69timer matches 20 run setblock 99858 24 99893 fire[west=true]

execute if score @s lvl69timer matches 45 run setblock 99858 24 99893 air
execute if score @s lvl69timer matches 45 run setblock 99857 24 99893 air
execute if score @s lvl69timer matches 45 run setblock 99856 24 99893 coal_block
execute if score @s lvl69timer matches 45 run setblock 99857 24 99893 fire[west=true]

execute if score @s lvl69timer matches 60 run setblock 99857 24 99893 air
execute if score @s lvl69timer matches 60 run setblock 99856 24 99893 air

#cannon 3
execute if score @s lvl69timer matches 70 run setblock 99863 24 99890 coal_block
execute if score @s lvl69timer matches 70 run particle minecraft:explosion 99863.9 24.5 99890 0 0 0 0.05 1 normal
execute if score @s lvl69timer matches 70 run playsound minecraft:entity.generic.explode master @a[scores={level=68..70}] 99864 24 99890 0.5 0.7

execute if score @s lvl69timer matches 85 run setblock 99863 24 99890 air
execute if score @s lvl69timer matches 85 run setblock 99862 24 99890 coal_block
execute if score @s lvl69timer matches 85 run setblock 99863 24 99890 fire[west=true]

execute if score @s lvl69timer matches 100 run setblock 99863 24 99890 air
execute if score @s lvl69timer matches 100 run setblock 99862 24 99890 air
execute if score @s lvl69timer matches 100 run setblock 99861 24 99890 coal_block
execute if score @s lvl69timer matches 100 run setblock 99862 24 99890 fire[west=true]

execute if score @s lvl69timer matches 115 run setblock 99862 24 99890 air
execute if score @s lvl69timer matches 115 run setblock 99861 24 99890 air
execute if score @s lvl69timer matches 115 run setblock 99860 24 99890 coal_block
execute if score @s lvl69timer matches 115 run setblock 99861 24 99890 fire[west=true]

execute if score @s lvl69timer matches 10 run setblock 99861 24 99890 air
execute if score @s lvl69timer matches 10 run setblock 99860 24 99890 air
execute if score @s lvl69timer matches 10 run setblock 99859 24 99890 coal_block
execute if score @s lvl69timer matches 10 run setblock 99860 24 99890 fire[west=true]

execute if score @s lvl69timer matches 25 run setblock 99860 24 99890 air
execute if score @s lvl69timer matches 25 run setblock 99859 24 99890 air
execute if score @s lvl69timer matches 25 run setblock 99858 24 99890 coal_block
execute if score @s lvl69timer matches 25 run setblock 99859 24 99890 fire[west=true]

execute if score @s lvl69timer matches 40 run setblock 99859 24 99890 air
execute if score @s lvl69timer matches 40 run setblock 99858 24 99890 air
execute if score @s lvl69timer matches 40 run setblock 99857 24 99890 coal_block
execute if score @s lvl69timer matches 40 run setblock 99858 24 99890 fire[west=true]

execute if score @s lvl69timer matches 55 run setblock 99858 24 99890 air
execute if score @s lvl69timer matches 55 run setblock 99857 24 99890 air
execute if score @s lvl69timer matches 55 run setblock 99856 24 99890 coal_block
execute if score @s lvl69timer matches 55 run setblock 99857 24 99890 fire[west=true]

execute if score @s lvl69timer matches 70 run setblock 99857 24 99890 air
execute if score @s lvl69timer matches 70 run setblock 99856 24 99890 air

scoreboard players reset @s[scores={lvl69timer=120..}] lvl69timer